"""CPU reproduction of the returned fresh run, not a new experiment."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
import time

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parent
sys.path.insert(0, str(WORKSPACE / 'gp_demo_20261007/plot_packages'))
import numpy as np
import scipy
import sklearn
from threadpoolctl import threadpool_limits


def main():
    started = time.perf_counter()
    received = ROOT / 'received_run'
    source = received / 'experiment.py'
    spec = importlib.util.spec_from_file_location('returned_frozen_fit', source)
    experiment = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(experiment)
    with np.load(received / 'data/features.npz') as f:
        X, domains, ids = f['X'], f['domains'], f['ids']
    records = []
    with threadpool_limits(limits=1):
        for seed in range(100, 120):
            with np.load(received / f'choices/seed_{seed}_choices.npz') as saved:
                results = experiment.fit_and_select(X, saved['train_y'], domains, ids,
                    saved['initial'], saved['remaining'], seed)
                for method, result in results.items():
                    difference = float(np.max(np.abs(saved[method+'_mu'] - result['mu'])))
                    same = np.array_equal(saved[method+'_chosen'], result['chosen'])
                    if not same or difference > 1e-6:
                        raise AssertionError((seed, method, difference, same))
                    records.append(dict(seed=seed, method=method,
                                        maximum_prediction_difference=difference,
                                        next60_identical=bool(same)))
            print('REPLAY', seed, 'five predictors: next60 identical', flush=True)
    result = dict(status='passed', purpose='CPU reproduction, no new data or GPU measurements',
                  source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                  numpy=np.__version__, scipy=scipy.__version__, sklearn=sklearn.__version__,
                  reproduced_fits=len(records), training_labels_per_fit=192,
                  all_next60_identical=True,
                  maximum_prediction_difference=max(r['maximum_prediction_difference'] for r in records),
                  records=records, seconds=time.perf_counter()-started)
    (ROOT / 'replay_audit.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print('REPLAY_PASSED', result['reproduced_fits'], result['maximum_prediction_difference'], flush=True)


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    main()
