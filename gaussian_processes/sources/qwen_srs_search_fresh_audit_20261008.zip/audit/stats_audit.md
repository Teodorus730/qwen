# Independent statistical audit

All 600 saved oracle means reproduce exactly from per-position float32 measurements; 20 saved plans have valid 192/408 partitions, 60 choices, 32/10 per domain, and matching training labels. Structural errors: 0.

Exact random next-top10 expectation: 14.705882%. KRR minus exact random: 19.294118%, conditional 95% bootstrap [17.544118%, 21.127451%], gate **positive**.

KRR minus GP: 0.333333%, conditional 95% bootstrap [-1.000000%, 1.750000%]; loss tolerance 1.666667%; gate **passes**. Joint replacement gate: True.

| Method | Next-top10 recall | Full top10 coverage after252 | Remaining MAE | Remaining R2 | Qwen seconds/252 | CPU seconds | Variable seconds |
|---|---:|---:|---:|---:|---:|---:|---:|
| gp | 33.667% | 52.500% | 0.008422 | 0.298033 | 102.888 | 0.369354 | 109.957 |
| krr | 34.000% | 52.917% | 0.008453 | 0.293166 | 102.871 | 0.207978 | 109.779 |
| bayesian_ridge | 32.500% | 52.000% | 0.008828 | 0.234486 | 102.808 | 0.050553 | 109.558 |
| cluster_mean | 20.333% | 45.167% | 0.009435 | 0.151983 | 102.895 | 0.160719 | 109.755 |
| domain_mean | 13.333% | 40.250% | 0.009362 | 0.166034 | 102.505 | 0.000998 | 102.506 |
| random | 15.000% | 41.750% | n/a | n/a | 102.941 | 0 | 102.941 |

| Domain | KRR recall | GP recall | Observed random recall | KRR − GP |
|---|---:|---:|---:|---:|
| computer_security | 26.50% | 25.00% | 15.50% | 1.50% |
| conceptual_physics | 25.00% | 26.00% | 13.50% | -1.00% |
| econometrics | 37.00% | 37.50% | 12.50% | -0.50% |
| formal_logic | 46.00% | 45.00% | 16.50% | 1.00% |
| machine_learning | 31.00% | 32.00% | 13.50% | -1.00% |
| public_relations | 38.50% | 36.50% | 18.50% | 2.00% |

KRR/GP paired seed signs: 8 positive, 3 tied, 9 negative.

All 600 rows were physically measured because the initial union is600. Recorded per-row Qwen times total 245.371s. Model loading 73.032s; BGE loading 7.284s and embeddings 6.700s; preparation wall 139.857s. Virtual 252-document totals are not actual full-run wall time.

KRR/GP CPU ratio 0.5631; variable cost ratio 0.9984. KRR/random variable cost ratio 1.0664.

Twenty repeated plans on one finite pool support conditional evidence only. Domain differences are descriptive. The result cannot establish universal GP replacement, arbitrary future-domain reliability, or downstream student training benefit. No source code imported/executed and no Qwen rerun.

Audited saved summary method means and both primary bootstrap intervals match independent recomputation within1e-12. Domain mean and random require no BGE.

Operational method cost including BGE loading and embeddings: KRR 117.062s; GP 117.241s; random 102.941s. KRR/GP 0.998477 (about 0.152% overall saving); KRR/random 1.137176 (about 13.718% additional recorded cost). Common Qwen loading and general preparation excluded.
