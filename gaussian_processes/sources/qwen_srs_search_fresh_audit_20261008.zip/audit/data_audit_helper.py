"""Independent CPU-only archive/data audit; never imports experiment/pipeline."""
from pathlib import Path
import hashlib, json, math, sys, zipfile
from collections import Counter
from datetime import datetime, timezone

BASE = Path(__file__).resolve().parent
WORK = BASE.parent
RUN = BASE / 'received_run'
ZIP = Path('C:/Users/admin/Desktop/qwen_srs_search_fresh_results.zip')
sys.path.insert(0, str(WORK / 'gp_demo_20261007/plot_packages'))
import numpy as np
from sklearn.feature_extraction.text import HashingVectorizer
from sklearn.neighbors import NearestNeighbors

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def fp(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                          separators=(',', ':')).encode()).hexdigest()

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def rows(path):
    return [json.loads(s) for s in Path(path).read_text(encoding='utf-8').splitlines() if s.strip()]

issues = []
checks = {}
def check(name, value, detail=None):
    checks[name] = {'pass': bool(value)}
    if detail is not None:
        checks[name]['detail'] = detail
    if not value:
        issues.append(name)

study = read(BASE / 'study.json')
manifest = read(BASE / 'build_manifest.json')
setup = read(RUN / 'data/setup.json')
selection = read(RUN / 'choices/selection_seal.json')
oracle_seal = read(RUN / 'data/oracle_seal.json')
pool = rows(RUN / 'data/pool.jsonl')
prior = rows(RUN / 'prior_texts.jsonl')
domains = np.array([r['domain'] for r in pool])
ids = np.array([r['sample_id'] for r in pool])
archive = zipfile.ZipFile(ZIP)
members = {i.filename: i for i in archive.infolist()}
print('identity and seals', flush=True)
check('zip_crc_integrity', archive.testzip() is None)
check('archive_unique_safe_paths', len(members) == len(archive.infolist()) and
      all(not n.startswith('/') and '..' not in Path(n).parts for n in members))
file_checks = {}
for name in manifest['input_files']:
    local_hash, received_hash = sha(BASE / name), sha(RUN / name)
    file_checks[name] = {'original_sha256': local_hash, 'received_sha256': received_hash,
                        'archive_sha256': hashlib.sha256(archive.read(name)).hexdigest()}
check('received_frozen_inputs_equal_original', all(len(set(x.values())) == 1 for x in file_checks.values()), file_checks)
check('study_equal_before_run_manifest', sha(RUN/'study.json') == manifest['study_sha256'])
check('source_hashes_match_frozen_study', all(sha(RUN/n) == h for n,h in study['source_sha256'].items()))
check('prior_hash_rows_match_frozen_study', sha(RUN/'prior_texts.jsonl') == study['prior_sha256'] and len(prior) == study['history_rows'])
check('historical_sources_match_original_inventory', all(sha(WORK/n) == h for n,h in study['historical_sources'].items()))
check('setup_study_and_source_identity', setup['study_sha256'] == sha(RUN/'study.json') and setup['source_sha256'] == study['source_sha256'])
check('setup_file_seals', all(sha(RUN/'data'/n) == h for n,h in setup['file_sha256'].items()))
check('setup_declares_zero_labels_and_plans_frozen', setup['fresh_measurements_at_seal'] == 0 and setup['plans_before_labels'] is True)
check('selection_file_seals_and_identity', len(selection['file_sha256']) == 40 and
      selection['study_sha256'] == sha(RUN/'study.json') and selection['setup_sha256'] == sha(RUN/'data/setup.json') and
      selection['source_sha256'] == study['source_sha256'] and
      all(sha(RUN/'choices'/n) == h for n,h in selection['file_sha256'].items()))
check('oracle_file_seals_and_selection_identity', sha(RUN/'data/oracle.npz') == oracle_seal['oracle_sha256'] and
      sha(RUN/'choices/selection_seal.json') == oracle_seal['selection_seal_sha256'])
receipts = {p.stem: read(p) for p in (RUN/'logs').glob('*_receipt.json')}
stages = ['check','prepare','initial','select','remaining','oracle','evaluate']
check('real_process_receipts_exit_zero', all(s+'_receipt' in receipts and receipts[s+'_receipt']['exit_code'] == 0 and
      receipts[s+'_receipt']['stage'] == s and receipts[s+'_receipt']['wall_seconds'] > 0 for s in stages), receipts)
logs = {s:(RUN/'logs'/f'{s}.log').read_text(encoding='utf-8') for s in stages}
check('stage_logs_no_error_traceback', all('Traceback (most recent call last)' not in log for log in logs.values()))
check('stage_completion_markers', 'SETUP_SEALED' in logs['prepare'] and 'MEASUREMENTS_COMPLETE initial 600 new calls 600' in logs['initial'] and
      'MEASUREMENTS_REUSED remaining 600 new calls 0' in logs['remaining'] and 'ORACLE_OPENED 600 texts' in logs['oracle'] and
      all(f'SELECTION_SAVED {s} 192 training labels' in logs['select'] for s in study['seeds']))
measurement_members = [i for n,i in members.items() if n.startswith('data/measurements/') and n.endswith('.npz')]
mtime = lambda n: members[n].date_time
chronology = {'setup_zip_mtime': mtime('data/setup.json'),
              'first_measurement_zip_mtime': min(i.date_time for i in measurement_members),
              'last_measurement_zip_mtime': max(i.date_time for i in measurement_members),
              'selection_zip_mtime': mtime('choices/selection_seal.json'),
              'oracle_zip_mtime': mtime('data/oracle.npz'),
              'setup_created_utc': setup['created_utc'], 'selection_created_utc': selection['created_utc']}
check('archive_recorded_stage_order', mtime('data/plans.json') <= mtime('data/setup.json') <=
      min(i.date_time for i in measurement_members) <= max(i.date_time for i in measurement_members) <=
      mtime('choices/selection_seal.json') <= mtime('data/oracle.npz'), chronology)

print('pool geometry and physical records', flush=True)
check('600_unique_ids_six_domains_100_each', len(pool) == 600 and len(set(ids)) == 600 and len(set(domains)) == 6 and all(v==100 for v in Counter(domains).values()), dict(Counter(domains)))
check('sample_id_source_identity', all(r['sample_id'] == fp(['mmlu', study['dataset_revision'], r['domain'], r['source_row']]) and
      r['source'] == study['dataset'] and r['revision'] == study['dataset_revision'] and r['source_split'] == study['split'] for r in pool))
geometry_errors = []
for i,r in enumerate(pool):
    a = r['alignment']; n = len(a['aligned_input_ids']); offsets = a['aligned_offsets']; e = a['encoder']
    conditions = [r['text'] == r['source_text'][:a['raw_end']], len(r['text']) == a['raw_end'],
      len(r['source_text']) == a['source_characters'], hashlib.sha256(r['text'].encode()).hexdigest() == a['raw_prefix_sha256'],
      hashlib.sha256(r['source_text'].encode()).hexdigest() == a['source_sha256'],
      a['aligned_input_ids'] == a['original_input_ids'][:n], offsets == a['original_offsets'][:n],
      0 < n <= 256, len(offsets) == n, a['aligned_qwen_tokens'] == n,
      a['original_qwen_seen_tokens'] == len(a['original_input_ids']),
      a['original_qwen_seen_tokens'] <= 256, a['original_full_qwen_tokens'] >= a['original_qwen_seen_tokens'],
      a['trimmed_qwen_tokens'] == len(a['original_input_ids'])-n,
      max(b for a0,b in offsets) == a['raw_end'],
      all(0 <= a0 < b <= a['raw_end'] for a0,b in offsets),
      hashlib.sha256(json.dumps(a['aligned_input_ids']).encode()).hexdigest() == a['aligned_ids_sha256'],
      a['qwen_input_ids_changed'] == (a['aligned_input_ids'] != a['original_input_ids']),
      a['teacher_verified'] and a['raw_prefix_retokenization_verified'],
      a['alignment_version'] == 'verified_raw_joint_prefix_v1', a['qwen_max_length'] == 256,
      e['total_tokens'] == e['seen_tokens'] <= 256, e['total_content_tokens'] == e['seen_content_tokens'],
      e['full_input_token_sequence_seen'] and not e['still_truncated'], e['input_token_coverage'] == 1,
      not e['input_has_tail_beyond_qwen_prefix'], e['qwen_positions'] == n,
      e['raw_input_characters'] == len(r['text']), e['truncation_side'] == 'right',
      0 <= e['qwen_positions_fully_covered_by_offsets'] <= e['qwen_positions_with_character_overlap'] <= n]
    if not all(conditions): geometry_errors.append({'row':i,'failed_checks':[j for j,c in enumerate(conditions) if not c]})
check('raw_prefix_and_alignment_geometry', not geometry_errors, geometry_errors)
with np.load(RUN/'data/features.npz', allow_pickle=False) as f:
    X = f['X']; norms = np.linalg.norm(X,axis=1)
    feature_info = {'shape':list(X.shape), 'dtype':str(X.dtype), 'norm_min':float(norms.min()), 'norm_max':float(norms.max()),
                    'exact_float32_roundtrip': bool(np.array_equal(X, X.astype(np.float32).astype(np.float64)))}
    check('bge_shape_l2_float32_origin_stored_float64', X.shape == (600,768) and str(X.dtype) == 'float64' and
          np.isfinite(X).all() and np.allclose(norms,1,rtol=0,atol=2e-7) and feature_info['exact_float32_roundtrip'] and
          np.array_equal(f['ids'],ids) and np.array_equal(f['domains'],domains),feature_info)
with np.load(RUN/'data/oracle.npz', allow_pickle=False) as f:
    oracle = {n:f[n].copy() for n in f.files}
check('oracle_array_shape_finiteness_bounds_identity', all(oracle[n].shape == (600,) for n in oracle) and
      np.array_equal(oracle['ids'],ids) and np.array_equal(oracle['domains'],domains) and
      np.isfinite(oracle['y']).all() and np.all((oracle['y'] >= -1e-6)&(oracle['y'] <= math.log(2)+1e-6)) and
      np.isfinite(oracle['qwen_seconds']).all() and np.all(oracle['qwen_seconds']>0))
measurements = list((RUN/'data/measurements').glob('*.npz'))
check('exactly_600_physical_records_and_sealed_hashes', len(measurements)==600 and len(oracle_seal['measurement_sha256'])==600 and
      all(sha(RUN/'data/measurements'/n)==h for n,h in oracle_seal['measurement_sha256'].items()))
record_errors = []; mins=[]; maxes=[]; counts=[]; seconds=[]; expected_names=[]
for i,r in enumerate(pool):
    key = fp({'study_sha256':sha(RUN/'study.json'),'setup_sha256':sha(RUN/'data/setup.json'),
              'sample_id':r['sample_id'],'raw_text_sha256':hashlib.sha256(r['text'].encode()).hexdigest()})
    expected_names.append(key+'.npz')
    with np.load(RUN/'data/measurements'/(key+'.npz'), allow_pickle=False) as f:
        exact = f['exact']; n = len(r['alignment']['aligned_input_ids'])
        cond = [exact.shape == (n,), str(exact.dtype)=='float32', np.isfinite(exact).all(),
                exact.min() >= -1e-6, exact.max() <= math.log(2)+1e-6,
                str(f['ids'].dtype)=='int32', f['ids'].tolist()==r['alignment']['aligned_input_ids'],
                str(f['offsets'].dtype)=='int32', f['offsets'].tolist()==r['alignment']['aligned_offsets'],
                str(f['sample_id'])==r['sample_id'], str(f['metric_key'])==key,
                float(exact.mean())==float(oracle['y'][i]), n==int(oracle['token_counts'][i]),
                float(f['qwen_seconds'])==float(oracle['qwen_seconds'][i]), np.isfinite(f['qwen_seconds']) and f['qwen_seconds']>0]
        if not all(cond): record_errors.append({'row':i,'failed_checks':[j for j,c in enumerate(cond) if not c]})
        mins.append(float(exact.min())); maxes.append(float(exact.max())); counts.append(n); seconds.append(float(f['qwen_seconds']))
check('per_position_jsd_records_match_oracle_exactly', not record_errors, record_errors)
check('measurement_identity_file_set_no_extra', set(expected_names)==set(p.name for p in measurements))
check('physical_position_count_matches_seal', sum(counts)==oracle_seal['total_positions']==45708 and oracle_seal['unique_fresh_pair_measurements']==600)

print('freshness and sampling plans', flush=True)
prior_norm = {' '.join(r['text'].split()) for r in prior}
old_pool = rows(WORK/'gp_task_confirmation_20261007/engine/results/data_sealed/pool.jsonl')
old_registry = read(WORK/'gp_task_confirmation_20261007/engine/results/data_sealed/prefix_registry.json')
old_ids = set(old_registry['prior_prefixes'])|set(old_registry['new_prefixes'].values())
new_ids = [fp(r['alignment']['aligned_input_ids']) for r in pool]
used_domains = {d for r in prior for d in r.get('domains',[r['domain']])}
check('new_domains_absent_from_all_saved_history', not used_domains.intersection(set(domains)), {'historical_domains':sorted(used_domains),'new_domains':sorted(set(domains))})
check('no_new_raw_or_prefix_normalized_exact_history_duplicates', all(' '.join(r[field].split()) not in prior_norm
      for r in pool for field in ['source_text','text']))
check('no_new_aligned_ids_duplicate_saved_legacy_joint_ids', not old_ids.intersection(new_ids),
      {'historical_id_hashes':len(old_ids),'old_prior_rows':old_registry['prior_count'],'oldB600_ids':len(old_registry['new_prefixes'])})
check('no_intra_new_pool_raw_prefix_ids_duplicates', len(set(new_ids))==600 and
      len({' '.join(r['text'].split()) for r in pool})==600 and len({' '.join(r['source_text'].split()) for r in pool})==600)
plans = read(RUN/'data/plans.json'); plan_errors=[]
for s in study['seeds']:
    p = plans[str(s)]; rng = np.random.default_rng(s+study['initial_seed_offset'])
    initial = np.concatenate([rng.choice(np.flatnonzero(domains==d),32,replace=False) for d in sorted(set(domains))])
    remaining = np.setdiff1d(np.arange(600),initial); rng = np.random.default_rng(s+study['random_next_seed_offset'])
    next_ = np.concatenate([rng.choice(remaining[domains[remaining]==d],10,replace=False) for d in sorted(set(domains))])
    if initial.tolist()!=p['initial'] or next_.tolist()!=p['random_next']: plan_errors.append(s)
check('all20_initial_and_random_plans_reproduced_frozen_rng', not plan_errors, plan_errors)
initial_union = len({i for p in plans.values() for i in p['initial']})
check('physical_initial_union_accounted', initial_union==600)
eligibility = read(RUN/'data/eligibility.json')
accepted = [d for d in study['domain_priority'] if d in eligibility and eligibility[d]['accepted']]
check('fallback_domains_follow_priority_and_eligibility_threshold', set(accepted)==set(domains) and len(accepted)==6 and
      all(e['accepted']==(e['eligible']>=100) and e['scanned']-sum(e['rejected'].values())==e['eligible'] for e in eligibility.values()),eligibility)

# Independent reconstruction of char5 vectors and cosine maximum against the
# complete saved raw history plus accessible aligned oldB600 views. No tokenizer.
vectorizer = HashingVectorizer(analyzer='char',ngram_range=(5,5),n_features=2**18,alternate_sign=False,dtype=np.float32)
historical_raw = [r['text'] for r in prior]
historical_available_views = historical_raw+[r['text'] for r in old_pool]
nearest = NearestNeighbors(n_neighbors=1,metric='cosine',algorithm='brute',n_jobs=2).fit(vectorizer.transform(historical_available_views))
similarities = {}
for field in ['source_text','text']:
    dist,ind = nearest.kneighbors(vectorizer.transform([r[field] for r in pool]))
    sim=1-dist[:,0]; k=int(np.argmax(sim)); closest=historical_available_views[int(ind[k,0])]
    similarities[field]={'max_cosine':float(sim[k]),'row':k,'sample_id':pool[k]['sample_id'],'violations_ge_0_92':int(np.sum(sim>=.92)),
                         'historical_view_index':int(ind[k,0]),'nearest_text_sha256':hashlib.sha256(closest.encode()).hexdigest()}
check('char5_fresh_raw_and_prefix_vs_all7467_raw_plus_oldB600_prefixes', all(x['violations_ge_0_92']==0 for x in similarities.values()),similarities)
prior_aligned_norm={' '.join(r['text'].split()) for r in old_pool}
check('no_new_normalized_raw_prefix_exact_oldB600_aligned_duplicates', all(' '.join(r[field].split()) not in prior_aligned_norm for r in pool for field in ['source_text','text']))

limitations = [
  'GPU forwards were not rerun. Per-position JSD vectors are audited for identities, dtype, bounds, mean and hash consistency; absent saved logits, their numerical derivation cannot be recomputed independently.',
  'No tokenizers runtime was available in the accessible Python environment. Raw-prefix hashes and stored ID/offset geometry were independently checked, but retokenization and BGE full-token coverage declarations were not independently recomputed.',
  'The complete raw historical set (7467 rows) and aligned prior confirmation B600 text views were independently checked for char5 cosine. All6963 saved legacy/joint token-ID hashes plus B600 hashes were checked. Joint text-prefix views of the earlier6867 rows were not all reconstructed, so full raw-and-prefix near-duplicate exclusion across those views remains supported by frozen source and run log, not this independent calculation.',
  'Eligibility scan/rejection counts and priority fallback are internally consistent and sealed before labels. Complete scanned candidates are not exported, so individual rejection decisions (including11 college_physics duplicates) were not independently reconstructed.',
  'Seals and archive timestamps establish internal recorded chronology; they are programmatic records without cryptographic attestation. All600 labels physically existed before per-seed fits; source isolation gives each fit only its192 training labels.'
]
result = {'schema':'independent_fresh_data_audit_v1','created_utc':datetime.now(timezone.utc).isoformat(),
 'archive':str(ZIP),'archive_sha256':sha(ZIP),'archive_bytes':ZIP.stat().st_size,'received_run':str(RUN),
 'execution':'CPU only; independent helper uses numpy2.1.3/scipy1.16.3/sklearn1.6.1; no GPU or experiment rerun',
 'status':'all_independent_checks_passed_with_explicit_scope_limits' if not issues else 'issues_found',
 'issues':issues,'checks':checks,'physical':{'rows':600,'initial_union':initial_union,'positions':sum(counts),
 'token_min':min(counts),'token_max':max(counts),'per_position_jsd_min':min(mins),'per_position_jsd_max':max(maxes),
 'qwen_seconds_sum':sum(seconds),'changed_raw_prefixes':sum(r['alignment']['qwen_input_ids_changed'] for r in pool)},
 'limitations':limitations}
(BASE/'data_audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
print(json.dumps({'status':result['status'],'issues':issues,'checks':len(checks),'physical':result['physical'],'similarities':similarities},ensure_ascii=False))
