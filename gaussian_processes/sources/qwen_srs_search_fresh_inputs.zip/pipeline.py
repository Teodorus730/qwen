"""Fresh-data confirmation: random domain map and one shared predictor for search.

Stages run in separate processes so Colab's already imported packages cannot
replace the frozen versions. The evaluator is deliberately separate from fit.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import gc
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import time
import zipfile

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
STUDY = json.loads((ROOT / 'study.json').read_text(encoding='utf-8'))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def fingerprint(value):
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True,
                         separators=(',', ':')).encode('utf-8')
    return hashlib.sha256(encoded).hexdigest()


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2,
                                   allow_nan=False), encoding='utf-8')
    temporary.replace(path)


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def read_rows(path):
    return [json.loads(line) for line in Path(path).read_text(
        encoding='utf-8').splitlines() if line.strip()]


def write_rows(path, rows):
    Path(path).write_text(''.join(json.dumps(row, ensure_ascii=False) + '\n'
                                  for row in rows), encoding='utf-8')


def check_runtime(gpu=False):
    import importlib.metadata
    for package, version in STUDY['runtime_pins'].items():
        actual = importlib.metadata.version(package)
        if actual != version:
            raise RuntimeError(f'{package}: expected {version}, got {actual}')
    import numpy as np
    import torch
    import transformers
    runtime = dict(python=sys.version.split()[0], numpy=np.__version__,
                   torch=torch.__version__, transformers=transformers.__version__,
                   cuda=torch.version.cuda, attention='sdpa', qwen_dtype='float16',
                   encoder_dtype='float32', metric_dtype='float32',
                   reduction='numpy_float32_mean')
    if gpu:
        if not torch.cuda.is_available():
            raise RuntimeError('Select a GPU runtime in Colab before this stage')
        runtime.update(gpu=torch.cuda.get_device_name(0),
                       gpu_gib=torch.cuda.get_device_properties(0).total_memory / 2**30,
                       free_gib=torch.cuda.mem_get_info()[0] / 2**30)
    print('RUNTIME', json.dumps(runtime), flush=True)
    return runtime


def check_sources():
    for filename, digest in STUDY['source_sha256'].items():
        if sha(ROOT / filename) != digest:
            raise RuntimeError(f'Frozen source changed: {filename}')
    if sha(ROOT / 'prior_texts.jsonl') != STUDY['prior_sha256']:
        raise RuntimeError('Historical input snapshot changed')


def load_tokenizers():
    from transformers import AutoTokenizer
    tokenizers = {}
    for role in ['student', 'teacher', 'encoder']:
        spec = STUDY['models'][role]
        tokenizers[role] = AutoTokenizer.from_pretrained(spec['id'], revision=spec['revision'])
    if tokenizers['student'].get_vocab() != tokenizers['teacher'].get_vocab():
        raise RuntimeError('Teacher and student need the same token vocabulary for this JSD')
    return tokenizers


def load_model(role):
    import torch
    from transformers import AutoModel, AutoModelForCausalLM
    spec = STUDY['models'][role]
    factory = AutoModel if role == 'encoder' else AutoModelForCausalLM
    started = time.perf_counter()
    model = factory.from_pretrained(spec['id'], revision=spec['revision'],
                                   dtype=torch.float32 if role == 'encoder' else torch.float16,
                                   attn_implementation='sdpa').to('cuda').eval()
    torch.cuda.synchronize()
    seconds = time.perf_counter() - started
    print('MODEL_READY', role, round(seconds, 2), 'seconds', flush=True)
    return model, seconds


def prepare():
    import numpy as np
    import torch
    from datasets import load_dataset
    from sklearn.feature_extraction.text import HashingVectorizer
    from sklearn.neighbors import NearestNeighbors
    from span_alignment import choose_joint_prefix, UnsafePrefixBoundary
    runtime = check_runtime(gpu=True)
    check_sources()
    DATA.mkdir(exist_ok=True)
    if (DATA / 'setup.json').exists():
        validate_setup(runtime)
        print('Reused the sealed pool and sampling plans; no new selection', flush=True)
        return
    if any((DATA / 'measurements').glob('*.npz')):
        raise RuntimeError('Measurements without a sealed setup: use a clean experiment folder')
    started = time.perf_counter()
    tokenizers = load_tokenizers()
    q, t, e = (tokenizers[role] for role in ['student', 'teacher', 'encoder'])
    prior = read_rows(ROOT / 'prior_texts.jsonl')
    used_domains = {d for row in prior for d in row.get('domains', [row['domain']])}
    if used_domains.intersection(STUDY['domain_priority']):
        raise RuntimeError('A candidate domain was already used in the supplied history')
    prior_norm, prior_ids, prior_views = set(), set(), []
    unsafe = 0
    for index, row in enumerate(prior):
        text = row['text']
        prior_norm.add(fingerprint(' '.join(text.split())))  # Dedup only, never a cache key.
        prior_ids.add(fingerprint(q(text, add_special_tokens=False, truncation=True,
                                   max_length=256, verbose=False)['input_ids']))
        prior_views.append(text)
        try:
            aligned = choose_joint_prefix(text, q, e, teacher_tokenizer=t,
                                          qwen_max_length=256, encoder_max_length=256)
        except UnsafePrefixBoundary:
            unsafe += 1
        else:
            prior_ids.add(fingerprint(list(aligned.input_ids)))
            prior_norm.add(fingerprint(' '.join(aligned.raw_prefix.split())))
            prior_views.append(aligned.raw_prefix)
        if (index + 1) % 1000 == 0:
            print('HISTORY', index + 1, '/', len(prior), flush=True)
    vectorizer = HashingVectorizer(analyzer='char', ngram_range=(5, 5),
                                  n_features=2**18, alternate_sign=False, dtype=np.float32)
    nearest = NearestNeighbors(n_neighbors=1, metric='cosine', algorithm='brute',
                               n_jobs=2).fit(vectorizer.transform(prior_views))
    chosen_rows, domain_audit = [], {}
    selected_norm, selected_ids = set(), set()
    threshold = 1 - STUDY['near_duplicate_cosine']
    # The priority and fallback rule are frozen before any new JSD is measured.
    for domain in STUDY['domain_priority']:
        candidates, rejected = [], Counter()
        seen_norm, seen_ids = set(selected_norm), set(selected_ids)
        stream = load_dataset('cais/mmlu', domain, revision=STUDY['dataset_revision'],
                              split='test', streaming=True)
        scanned = 0
        for index, item in enumerate(stream):
            scanned += 1
            # Correct answers and MMLU accuracy are not used here.
            text = '\n'.join([item['question'].strip()] +
                             [f'{chr(65+j)}. {str(v).strip()}' for j, v in enumerate(item['choices'])] +
                             ['Answer:'])
            norm = fingerprint(' '.join(text.split()))
            if norm in prior_norm:
                rejected['historical_raw_duplicate'] += 1
                continue
            try:
                aligned = choose_joint_prefix(text, q, e, teacher_tokenizer=t,
                                              qwen_max_length=256, encoder_max_length=256)
            except UnsafePrefixBoundary:
                rejected['unsafe_raw_boundary'] += 1
                continue
            prefix_key = fingerprint(list(aligned.input_ids))
            anorm = fingerprint(' '.join(aligned.raw_prefix.split()))
            if prefix_key in prior_ids or anorm in prior_norm:
                rejected['historical_qwen_or_joint_prefix'] += 1
                continue
            if prefix_key in seen_ids or norm in seen_norm or anorm in seen_norm:
                rejected['new_pool_duplicate'] += 1
                continue
            seen_ids.add(prefix_key)
            seen_norm.update([norm, anorm])
            row = dict(domain=domain, sample_id=fingerprint([
                'mmlu', STUDY['dataset_revision'], domain, index]),
                source='cais/mmlu', revision=STUDY['dataset_revision'], source_split='test',
                source_row=index, source_text=text, text=aligned.raw_prefix,
                alignment=aligned.metadata())
            candidates.append(row)
        if candidates:
            raw_dist, _ = nearest.kneighbors(vectorizer.transform([r['source_text'] for r in candidates]))
            prefix_dist, _ = nearest.kneighbors(vectorizer.transform([r['text'] for r in candidates]))
            eligible = [row for row, raw, prefix in zip(candidates, raw_dist[:, 0], prefix_dist[:, 0])
                        if min(raw, prefix) > threshold]
        else:
            eligible = []
        rejected['historical_near_duplicate'] = len(candidates) - len(eligible)
        eligible.sort(key=lambda r: fingerprint(['fresh_hybrid', STUDY['data_seed'], r['sample_id']]))
        accepted = len(eligible) >= 100
        domain_audit[domain] = dict(scanned=scanned, eligible=len(eligible),
                                    accepted=accepted, rejected=dict(rejected))
        print('DOMAIN', domain, 'eligible', len(eligible), 'accepted', accepted, flush=True)
        if not accepted:
            continue
        selected = eligible[:100]
        chosen_rows.extend(selected)
        for row in selected:
            selected_ids.add(fingerprint(row['alignment']['aligned_input_ids']))
            selected_norm.update([fingerprint(' '.join(row['source_text'].split())),
                                  fingerprint(' '.join(row['text'].split()))])
        if len(chosen_rows) == 600:
            break
    write_json(DATA / 'eligibility.json', domain_audit)
    if len(chosen_rows) != 600:
        raise RuntimeError('Fewer than six eligible domains. No Qwen labels were measured; '
                           'send eligibility.json before changing the protocol.')
    # Sorted domain order keeps the same sampling semantics as the development run.
    chosen_rows.sort(key=lambda r: (r['domain'], fingerprint([
        'fresh_hybrid', STUDY['data_seed'], r['sample_id']])))
    domains = np.array([r['domain'] for r in chosen_rows])
    ids = np.array([r['sample_id'] for r in chosen_rows])
    write_rows(DATA / 'pool.jsonl', chosen_rows)
    plans = {}
    for seed in STUDY['seeds']:
        rng = np.random.default_rng(seed + 10000)
        initial = np.concatenate([rng.choice(np.flatnonzero(domains == d), 32, replace=False)
                                  for d in sorted(set(domains))])
        remaining = np.setdiff1d(np.arange(600), initial)
        rng = np.random.default_rng(STUDY['random_next_seed_offset'] + seed)
        random_next = np.concatenate([rng.choice(remaining[domains[remaining] == d], 10,
                                                 replace=False) for d in sorted(set(domains))])
        plans[str(seed)] = dict(initial=initial.tolist(), random_next=random_next.tolist())
    write_json(DATA / 'plans.json', plans)
    # Independent BGE uses exactly the same raw text prefix as both Qwen models.
    encoder, model_seconds = load_model('encoder')
    vectors = []
    torch.cuda.synchronize()
    embed_start = time.perf_counter()
    with torch.inference_mode():
        for start in range(0, 600, 32):
            texts = [r['text'] for r in chosen_rows[start:start+32]]
            batch = e(texts, padding=True, truncation=False, return_tensors='pt')
            if batch['input_ids'].shape[1] > 256:
                raise RuntimeError('BGE still truncates the supposedly aligned raw prefix')
            batch = batch.to('cuda')
            cls = encoder(**batch).last_hidden_state.float()[:, 0]
            cls = torch.nn.functional.normalize(cls, p=2, dim=1)
            vectors.append(cls.cpu().numpy())
    torch.cuda.synchronize()
    embedding_seconds = time.perf_counter() - embed_start
    # The frozen DomainMap passed BGE's float32 output to sklearn as float64.
    X = np.concatenate(vectors).astype(float)
    del encoder, batch, cls
    gc.collect()
    torch.cuda.empty_cache()
    np.savez_compressed(DATA / 'features.npz', X=X, ids=ids, domains=domains)
    setup_files = ['pool.jsonl', 'plans.json', 'features.npz', 'eligibility.json']
    write_json(DATA / 'setup.json', dict(
        study_sha256=sha(ROOT / 'study.json'), source_sha256=STUDY['source_sha256'],
        created_utc=datetime.now(timezone.utc).isoformat(), runtime=runtime,
        prior_rows=len(prior), prior_sha256=STUDY['prior_sha256'], prior_unsafe_boundaries=unsafe,
        pool_size=600, domains=sorted(set(domains)), fresh_measurements_at_seal=0,
        plans_before_labels=True, file_sha256={name: sha(DATA / name) for name in setup_files},
        bge_model_loading_seconds=model_seconds, bge_embedding_seconds=embedding_seconds,
        preparation_seconds=time.perf_counter() - started,
        changed_qwen_prefixes=sum(r['alignment']['qwen_input_ids_changed'] for r in chosen_rows)))
    print('SETUP_SEALED', sorted(set(domains)), '600 texts; 0 Qwen measurements', flush=True)


def validate_setup(runtime=None):
    check_sources()
    setup = read_json(DATA / 'setup.json')
    if setup['study_sha256'] != sha(ROOT / 'study.json'):
        raise RuntimeError('Study changed after pool freeze')
    for filename, digest in setup['file_sha256'].items():
        if sha(DATA / filename) != digest:
            raise RuntimeError(f'Sealed input changed: {filename}')
    if runtime is not None:
        # Free VRAM is variable, GPU/compute settings are part of the cached measurement.
        for key in ['torch', 'numpy', 'transformers', 'cuda', 'attention', 'gpu',
                    'qwen_dtype', 'encoder_dtype', 'metric_dtype', 'reduction']:
            if runtime[key] != setup['runtime'][key]:
                raise RuntimeError(f'Runtime changed after preparation: {key}')
    return setup


def measurement_path(row):
    identity = fingerprint(dict(study_sha256=sha(ROOT / 'study.json'),
                                setup_sha256=sha(DATA / 'setup.json'), sample_id=row['sample_id'],
                                raw_text_sha256=hashlib.sha256(row['text'].encode('utf-8')).hexdigest()))
    return DATA / 'measurements' / (identity + '.npz')


def metric_exact(a, b):
    import torch
    values = []
    for start in range(0, len(a), 8):
        logp = a[start:start+8].float().log_softmax(-1)
        logq = b[start:start+8].float().log_softmax(-1)
        logm = torch.logaddexp(logp, logq) - math.log(2.)
        jsd = .5 * ((logp.exp() * (logp-logm)).sum(-1) +
                    (logq.exp() * (logq-logm)).sum(-1))
        values.append(jsd.cpu())
    return torch.cat(values).numpy()


def measure(stage):
    import numpy as np
    import torch
    runtime = check_runtime(gpu=True)
    setup = validate_setup(runtime)
    pool = read_rows(DATA / 'pool.jsonl')
    plans = read_json(DATA / 'plans.json')
    if stage == 'initial':
        indices = sorted({i for plan in plans.values() for i in plan['initial']})
    else:
        # Opening the complete oracle requires saved predictions for every seed.
        validate_choices()
        indices = list(range(600))
    selected = [pool[i] for i in indices]
    missing = [r for r in selected if not measurement_path(r).exists()]
    print('MEASUREMENTS_REQUESTED', stage, len(selected), 'unique texts;',
          len(missing), 'uncached pairs', flush=True)
    if not missing:
        print('MEASUREMENTS_REUSED', stage, len(selected), 'new calls 0', flush=True)
        return
    started = time.perf_counter()
    tokenizers = load_tokenizers()
    student, student_load = load_model('student')
    teacher, teacher_load = load_model('teacher')
    destination = DATA / 'measurements'
    destination.mkdir(exist_ok=True)
    for index, row in enumerate(missing):
        ids = tokenizers['student'](row['text'], add_special_tokens=False,
                                     truncation=False, return_offsets_mapping=True)
        teacher_ids = tokenizers['teacher'](row['text'], add_special_tokens=False,
                                            truncation=False)['input_ids']
        if ids['input_ids'] != row['alignment']['aligned_input_ids'] or teacher_ids != ids['input_ids']:
            raise RuntimeError('Qwen input IDs differ from the sealed raw-prefix alignment')
        inputs = torch.tensor([ids['input_ids']], device='cuda')
        torch.cuda.synchronize()
        document_start = time.perf_counter()
        with torch.inference_mode():
            a = teacher(input_ids=inputs, attention_mask=torch.ones_like(inputs),
                        use_cache=False).logits[0]
            b = student(input_ids=inputs, attention_mask=torch.ones_like(inputs),
                        use_cache=False).logits[0]
            if a.shape != b.shape:
                raise RuntimeError('Qwen logit shapes differ')
            exact = metric_exact(a, b)
        torch.cuda.synchronize()
        document_seconds = time.perf_counter() - document_start
        if not np.isfinite(exact).all() or exact.min() < -1e-6 or exact.max() > math.log(2)+1e-6:
            raise RuntimeError('Nonfinite or invalid full-vocabulary JSD')
        path = measurement_path(row)
        temporary = path.with_suffix('.tmp.npz')
        np.savez_compressed(temporary, exact=exact,
                            ids=np.array(ids['input_ids'], dtype=np.int32),
                            offsets=np.array(ids['offset_mapping'], dtype=np.int32),
                            sample_id=np.array(row['sample_id']), metric_key=np.array(path.stem),
                            qwen_seconds=document_seconds)
        temporary.replace(path)
        del a, b, inputs
        if (index+1) % 25 == 0 or index+1 == len(missing):
            print('JSD', stage, index+1, '/', len(missing),
                  'new texts;', round(time.perf_counter()-started, 1), 'seconds', flush=True)
    receipts = DATA / 'receipts'
    receipts.mkdir(exist_ok=True)
    write_json(receipts / f'{stage}_{time.time_ns()}.json', dict(
        stage=stage, unique_requested=len(selected), new_pair_calls=len(missing),
        student_loading_seconds=student_load, teacher_loading_seconds=teacher_load,
        wall_seconds=time.perf_counter()-started, setup_sha256=sha(DATA / 'setup.json')))
    print('MEASUREMENTS_COMPLETE', stage, len(selected), 'new calls', len(missing), flush=True)


def load_labels(pool, indices):
    import numpy as np
    values = []
    for i in indices:
        row = pool[int(i)]
        path = measurement_path(row)
        with np.load(path) as data:
            if str(data['sample_id']) != row['sample_id'] or str(data['metric_key']) != path.stem:
                raise RuntimeError('Measurement identity mismatch')
            if data['ids'].tolist() != row['alignment']['aligned_input_ids']:
                raise RuntimeError('Cached token IDs differ from the sealed input')
            values.append(float(data['exact'].mean()))
    return np.array(values)


def select():
    import numpy as np
    from threadpoolctl import threadpool_limits
    from experiment import fit_and_select
    check_runtime()
    validate_setup()
    if (ROOT / 'choices/selection_seal.json').exists():
        validate_choices()
        print('Reused all saved predictions; no refitting after oracle access', flush=True)
        return
    if (DATA / 'oracle.npz').exists():
        raise RuntimeError('Cannot create new selections after the full oracle was opened')
    pool = read_rows(DATA / 'pool.jsonl')
    plans = read_json(DATA / 'plans.json')
    with np.load(DATA / 'features.npz') as data:
        X, domains, ids = data['X'], data['domains'], data['ids']
    directory = ROOT / 'choices'
    directory.mkdir(exist_ok=True)
    with threadpool_limits(limits=1):
        for seed in STUDY['seeds']:
            initial = np.array(plans[str(seed)]['initial'], dtype=int)
            remaining = np.setdiff1d(np.arange(600), initial)
            # Only this seed's 192 measurements are loaded for fitting.
            train_y = load_labels(pool, initial)
            fit_start = time.perf_counter()
            predictions = fit_and_select(X, train_y, domains, ids, initial, remaining, seed)
            arrays = dict(initial=initial, remaining=remaining, train_y=train_y,
                          random_chosen=np.array(plans[str(seed)]['random_next'], dtype=int))
            metadata = {}
            for method, result in predictions.items():
                arrays[method+'_mu'] = result['mu']
                arrays[method+'_chosen'] = result['chosen']
                metadata[method] = {k: result[k] for k in [
                    'fit_seconds', 'prediction_seconds', 'selection_seconds',
                    'parameters', 'cv_scores', 'warnings']}
            metadata['_all_methods_wall_seconds'] = time.perf_counter() - fit_start
            np.savez_compressed(directory / f'seed_{seed}_choices.npz', **arrays)
            write_json(directory / f'seed_{seed}_fit.json', metadata)
            print('SELECTION_SAVED', seed, '192 training labels; 60 next texts per method', flush=True)
    files = sorted(list(directory.glob('seed_*_choices.npz')) + list(directory.glob('seed_*_fit.json')))
    write_json(directory / 'selection_seal.json', dict(
        study_sha256=sha(ROOT / 'study.json'), setup_sha256=sha(DATA / 'setup.json'),
        source_sha256=STUDY['source_sha256'], oracle_aggregated_before_selection=False,
        created_utc=datetime.now(timezone.utc).isoformat(),
        file_sha256={p.name: sha(p) for p in files}))


def validate_choices():
    validate_setup()
    seal = read_json(ROOT / 'choices/selection_seal.json')
    if seal['setup_sha256'] != sha(DATA / 'setup.json') or seal['study_sha256'] != sha(ROOT / 'study.json'):
        raise RuntimeError('Selections belong to another study or pool')
    if len(seal['file_sha256']) != 2 * len(STUDY['seeds']):
        raise RuntimeError('Missing saved selection for a seed')
    for filename, digest in seal['file_sha256'].items():
        if sha(ROOT / 'choices' / filename) != digest:
            raise RuntimeError(f'Saved prediction changed: {filename}')
    return seal


def open_oracle():
    import numpy as np
    check_runtime()
    validate_choices()
    pool = read_rows(DATA / 'pool.jsonl')
    values = load_labels(pool, np.arange(600))  # First full-pool target aggregation.
    seconds, positions = [], []
    for row in pool:
        with np.load(measurement_path(row)) as data:
            seconds.append(float(data['qwen_seconds']))
            positions.append(len(data['exact']))
    np.savez_compressed(DATA / 'oracle.npz', y=values,
                        ids=np.array([r['sample_id'] for r in pool]),
                        domains=np.array([r['domain'] for r in pool]),
                        token_counts=np.array(positions), qwen_seconds=np.array(seconds))
    write_json(DATA / 'oracle_seal.json', dict(
        oracle_sha256=sha(DATA / 'oracle.npz'),
        selection_seal_sha256=sha(ROOT / 'choices/selection_seal.json'),
        pool_size=600, total_positions=sum(positions),
        unique_fresh_pair_measurements=600,
        measurement_sha256={measurement_path(r).name: sha(measurement_path(r)) for r in pool}))
    print('ORACLE_OPENED', len(values), 'texts;', sum(positions), 'token positions', flush=True)


def package():
    target = ROOT.parent / 'qwen_srs_search_fresh_results.zip'
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(ROOT.rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.tmp':
                archive.write(path, path.relative_to(ROOT))
    print('RESULT_ARCHIVE', str(target), 'bytes', target.stat().st_size, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('stage', choices=['check', 'prepare', 'initial', 'select',
                                        'remaining', 'oracle', 'evaluate', 'package'])
    args = parser.parse_args()
    if args.stage == 'check':
        check_runtime(gpu=True)
        check_sources()
    elif args.stage == 'prepare':
        prepare()
    elif args.stage in ['initial', 'remaining']:
        measure(args.stage)
    elif args.stage == 'select':
        select()
    elif args.stage == 'oracle':
        open_oracle()
    elif args.stage == 'evaluate':
        check_runtime()
        validate_choices()
        from evaluation import evaluate
        evaluate(ROOT, STUDY)
    else:
        package()
