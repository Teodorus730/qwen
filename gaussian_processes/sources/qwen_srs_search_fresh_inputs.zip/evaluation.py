"""Score sealed selections on the fresh oracle without fitting any model.

The import from experiment.py deliberately reuses the frozen development scoring
and bootstrap functions. No fit_and_select call occurs in this module.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import math
import platform
import time

import numpy as np
from scipy.stats import spearmanr


PREDICTORS = ["gp", "krr", "bayesian_ridge", "cluster_mean", "domain_mean"]
METHODS = PREDICTORS + ["random"]
NAMES = {"gp": "GP", "krr": "KRR", "bayesian_ridge": "Bayesian ridge",
         "cluster_mean": "Cluster mean", "domain_mean": "Domain mean", "random": "Random"}


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _clean(value):
    """JSON null preserves undefined correlations/R2 instead of dropping rows."""
    if isinstance(value, dict):
        return {str(k): _clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_clean(v) for v in value]
    if isinstance(value, np.ndarray):
        return _clean(value.tolist())
    if isinstance(value, (float, np.floating)):
        return float(value) if math.isfinite(float(value)) else None
    if isinstance(value, np.integer):
        return int(value)
    if isinstance(value, np.bool_):
        return bool(value)
    return value


def _write(path, value):
    Path(path).write_text(json.dumps(_clean(value), ensure_ascii=False, indent=2,
                                    allow_nan=False), encoding="utf-8")


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def _frozen(root):
    path = root / "experiment.py"
    spec = importlib.util.spec_from_file_location("fresh_frozen_experiment", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    _require(list(module.PREDICTORS) == PREDICTORS, "Frozen predictor list differs")
    return module


def _verify_seal(root, study, seeds):
    seal_path = root / "choices" / "selection_seal.json"
    seal = _read(seal_path)
    setup_path = root / "data" / "setup.json"
    setup = _read(setup_path)
    study_digest = _sha(root / "study.json")
    _require(seal["study_sha256"] == study_digest == setup["study_sha256"],
             "Study SHA256 differs from setup/selection seal")
    _require(_read(root / "study.json") == study, "evaluate() study differs from saved study.json")
    _require(seal["setup_sha256"] == _sha(setup_path), "Setup SHA256 differs from selection seal")
    _require(seal["oracle_aggregated_before_selection"] is False,
             "Selection seal declares premature oracle aggregation")
    checked = {}
    for folder, expected in [(root / "data", setup["file_sha256"]),
                             (root / "choices", seal["file_sha256"]),
                             (root, study.get("source_sha256", {}))]:
        _require(isinstance(expected, dict), "Seal lacks SHA256 file map")
        for name, digest in expected.items():
            name = str(name).replace("\\", "/")
            path = (folder / name).resolve()
            _require(path.is_relative_to(folder.resolve()), "Seal references an external path: " + name)
            _require(path.is_file(), "Missing sealed file: " + name)
            _require(isinstance(digest, str) and _sha(path) == digest,
                     "SHA256 mismatch for sealed file: " + name)
            checked[path.relative_to(root).as_posix()] = digest
    required = ["data/features.npz", "data/plans.json"]
    for seed in seeds:
        required.extend([f"choices/seed_{seed}_choices.npz", f"choices/seed_{seed}_fit.json"])
    _require(all(name in checked for name in required),
             "Seal must cover features, plans, every saved choice and every fit timing")
    _require(len(seal["file_sha256"]) == 2 * len(seeds), "Expected exactly 40 sealed choice/fit files")
    oracle_path = root / "data" / "oracle.npz"
    oracle_seal_path = root / "data" / "oracle_seal.json"
    oracle_seal = _read(oracle_seal_path)
    _require(oracle_seal["oracle_sha256"] == _sha(oracle_path), "Oracle SHA256 mismatch")
    _require(oracle_seal["selection_seal_sha256"] == _sha(seal_path),
             "Oracle belongs to a different selection seal")
    _require(oracle_seal["pool_size"] == 600 and oracle_seal["unique_fresh_pair_measurements"] == 600,
             "Oracle seal must document 600 unique physical measurements")
    measurements = oracle_seal["measurement_sha256"]
    _require(len(measurements) == 600, "Oracle seal lacks 600 physical measurement hashes")
    for filename, digest in measurements.items():
        path = (root / "data" / "measurements" / filename).resolve()
        _require(path.is_relative_to((root / "data" / "measurements").resolve()), "External measurement path")
        _require(path.is_file() and _sha(path) == digest, "Physical measurement SHA256 mismatch: " + filename)
        checked[path.relative_to(root).as_posix()] = digest
    checked["data/setup.json"] = _sha(setup_path)
    checked["data/oracle.npz"] = _sha(oracle_path)
    checked["data/oracle_seal.json"] = _sha(oracle_seal_path)
    return {"path": seal_path.relative_to(root).as_posix(), "sha256": _sha(seal_path),
            "study_sha256": study_digest, "verified_files": checked,
            "all_required_files_verified": True, "oracle_total_positions": oracle_seal["total_positions"]}


def _rank(left, right):
    left, right = np.asarray(left, dtype=float), np.asarray(right, dtype=float)
    if len(left) < 2 or np.ptp(left) == 0 or np.ptp(right) == 0:
        return None
    rho = float(spearmanr(left, right).statistic)
    return rho if math.isfinite(rho) else None


def _verify_physical_oracle(root, seal, y, ids, domains, counts, qwen):
    """Reconstruct oracle rows independently from sealed per-document results."""
    pool_path = root / "data" / "pool.jsonl"
    pool = [json.loads(line) for line in pool_path.read_text(encoding="utf-8").splitlines()
            if line.strip()]
    _require(len(pool) == len(y), "Pool/oracle row count differs")
    _require([row["sample_id"] for row in pool] == ids.tolist(), "Ordered pool/oracle IDs differ")
    _require([row["domain"] for row in pool] == domains.tolist(), "Ordered pool/oracle domains differ")
    by_id = {sample_id: index for index, sample_id in enumerate(ids.tolist())}
    seen = set()
    for filename in seal["verified_files"]:
        if not filename.startswith("data/measurements/"):
            continue
        path = root / filename
        with np.load(path, allow_pickle=False) as measurement:
            sample_id = str(measurement["sample_id"])
            _require(sample_id in by_id and sample_id not in seen,
                     "Physical measurement has unknown/duplicate sample_id: " + filename)
            index = by_id[sample_id]
            _require(str(measurement["metric_key"]) == path.stem,
                     "Physical metric_key differs from filename: " + filename)
            _require(measurement["ids"].tolist() == pool[index]["alignment"]["aligned_input_ids"],
                     "Physical token IDs differ from sealed alignment: " + filename)
            exact = measurement["exact"]
            _require(exact.ndim == 1 and len(exact) > 0 and bool(np.all(np.isfinite(exact))),
                     "Invalid physical exact JSD vector: " + filename)
            _require(float(exact.mean()) == float(y[index]),
                     "Aggregated oracle y differs from physical exact mean: " + filename)
            _require(len(exact) == int(counts[index]) == len(measurement["ids"]),
                     "Aggregated oracle token count differs from physical measurement: " + filename)
            _require(float(measurement["qwen_seconds"]) == float(qwen[index]),
                     "Aggregated oracle Qwen seconds differ from physical measurement: " + filename)
            seen.add(sample_id)
    _require(len(seen) == len(y), "Not every oracle row has a verified physical measurement")
    return {"verified_documents": len(seen), "ordered_pool_ids_match": True,
            "physical_exact_means_equal_oracle_y": True,
            "physical_token_counts_equal_oracle_counts": True,
            "physical_qwen_seconds_equal_oracle_seconds": True,
            "physical_token_ids_equal_sealed_alignment": True}


def _theta_worst(estimate, truth):
    # Deterministic domain-name order breaks ties in the estimated minimum;
    # any domain tied at the true minimum counts as a correct selection.
    chosen = min(sorted(estimate), key=lambda domain: (estimate[domain], domain))
    true_minimum = min(truth.values())
    return {"domain": chosen, "correct": float(truth[chosen] == true_minimum),
            "regret": float(truth[chosen] - true_minimum)}


def _indices(value, n, name):
    values = np.asarray(value)
    _require(values.ndim == 1 and np.issubdtype(values.dtype, np.integer),
             name + " must be a one-dimensional integer array")
    values = values.astype(int)
    _require(len(set(values.tolist())) == len(values), name + " contains duplicate indices")
    _require(bool(np.all((values >= 0) & (values < n))), name + " contains invalid indices")
    return values


def _fit_records(path):
    value = _read(path)
    _require(isinstance(value, dict) and all(k in value for k in PREDICTORS),
             "Fit timing file lacks a predictor")
    result = {}
    for kind in PREDICTORS:
        row = value[kind]
        result[kind] = {}
        for key in ["fit_seconds", "prediction_seconds", "selection_seconds"]:
            number = float(row[key])
            _require(math.isfinite(number) and number >= 0, "Invalid recorded " + key)
            result[kind][key] = number
        for key in ["parameters", "cv_scores", "warnings"]:
            result[kind][key] = row.get(key)
    return result


def _interval(values, seed, frozen):
    # Any undefined value leaves this statistic undefined; do not silently
    # change the cohort by dropping constant-score or constant-target seeds.
    defined = sum(v is not None and math.isfinite(float(v)) for v in values)
    if defined != len(values):
        return {"mean": None, "conditional_95": None, "n": len(values),
                "defined_seeds": defined, "undefined_seeds": len(values) - defined,
                "bootstrap_seed": seed,
                "reason": "Undefined values retained; no complete-cohort mean or interval"}
    interval = frozen.paired_interval(values, seed)
    interval.update(defined_seeds=defined, undefined_seeds=0,
                    minimum=float(min(values)), maximum=float(max(values)),
                    bootstrap_seed=seed)
    return interval


def _bge_cost(root):
    """Use actual pipeline metadata, never estimate an unrecorded BGE duration."""
    path = root / "data" / "setup.json"
    metadata = _read(path)
    values = {key: float(metadata[key]) for key in
              ["bge_model_loading_seconds", "bge_embedding_seconds"]}
    _require(all(math.isfinite(value) and value >= 0 for value in values.values()), "Invalid BGE timings")
    return {"seconds": sum(values.values()), "documents": 600, **values,
            "all_preparation_seconds": float(metadata["preparation_seconds"]),
            "source": path.relative_to(root).as_posix(), "source_sha256": _sha(path),
            "meaning": "Measured BGE loading plus embedding600; broader preparation duration reported separately"}


def _sources(root, seal):
    sources = dict(seal["verified_files"])
    for name in ["study.json", "experiment.py", "evaluation.py", "pipeline.py", "prior_texts.jsonl",
                 "data/oracle.npz", "data/oracle_seal.json", "data/setup.json", "data/pool.jsonl",
                 "data/eligibility.json"]:
        path = root / name
        if path.is_file():
            sources[name] = _sha(path)
    for path in sorted((root / "data" / "receipts").glob("*.json")):
        sources[path.relative_to(root).as_posix()] = _sha(path)
    sources[seal["path"]] = seal["sha256"]
    return sources


def _metrics(frozen, y, domains, ids, counts, initial, remaining, chosen, mu, qwen, fits, bge, method):
    with np.errstate(divide="ignore", invalid="ignore"):
        result = _clean(frozen.score_choices(y, domains, ids, counts, initial, remaining, chosen, mu))
    regrets = []
    for domain in sorted(set(domains.tolist())):
        rest = remaining[domains[remaining] == domain]
        acquired = chosen[domains[chosen] == domain]
        oracle_top = frozen.top_indices(rest, y, ids, 10)
        regret = float(y[oracle_top].mean() - y[acquired].mean())
        # Roundoff alone may produce a tiny negative regret.
        if -1e-14 < regret < 0:
            regret = 0.0
        _require(regret >= 0, "Oracle top10 regret must be nonnegative")
        row = result["by_domain"][domain]
        row["oracle_top10_mean_jsd"] = float(y[oracle_top].mean())
        row["next_mean_jsd_regret"] = regret
        row["next_recall_regret"] = 1 - row["remaining_top10_recall"]
        if mu is not None:
            row["remaining_spearman"] = _rank(y[rest], mu[rest])
        regrets.append(regret)
    result["mean_domain_jsd_regret"] = float(np.mean(regrets))
    result["worst_domain_jsd_regret"] = float(max(regrets))
    result["worst_domain_recall_regret"] = float(max(v["next_recall_regret"] for v in result["by_domain"].values()))
    result["worst_domain_recall"] = float(min(v["remaining_top10_recall"] for v in result["by_domain"].values()))
    if mu is not None:
        result["remaining_spearman"] = _rank(y[remaining], mu[remaining])
    result["virtual_initial_documents"] = len(initial)
    result["virtual_next_documents"] = len(chosen)
    result["virtual_total_documents"] = len(initial) + len(chosen)
    result["qwen_initial_recorded_seconds"] = float(qwen[initial].sum())
    result["qwen_next_recorded_seconds"] = float(qwen[chosen].sum())
    result["qwen_virtual252_recorded_seconds"] = float(qwen[np.r_[initial, chosen]].sum())
    result["bge_fixed600_seconds"] = bge["seconds"] if method in ["gp", "krr", "bayesian_ridge", "cluster_mean"] else 0.0
    if fits is not None:
        result.update(fits)
        result["predictor_cpu_recorded_seconds"] = sum(fits[k] for k in
                    ["fit_seconds", "prediction_seconds", "selection_seconds"])
    else:
        result.update(fit_seconds=0.0, prediction_seconds=0.0,
                      selection_seconds=None, predictor_cpu_recorded_seconds=None)
    if result["bge_fixed600_seconds"] is not None and result["predictor_cpu_recorded_seconds"] is not None:
        result["virtual252_qwen_plus_bge_plus_cpu_seconds"] = (
            result["qwen_virtual252_recorded_seconds"] + result["bge_fixed600_seconds"] +
            result["predictor_cpu_recorded_seconds"])
    else:
        result["virtual252_qwen_plus_bge_plus_cpu_seconds"] = None
    return result


def _aggregate(records, seed, frozen):
    methods = {}
    for number, method in enumerate(METHODS):
        rows = [record["methods"][method] for record in records]
        keys = [key for key, value in rows[0].items()
                if isinstance(value, (int, float)) or value is None]
        # Parameters/CV/warnings are saved per seed, not arithmetic quantities.
        keys = [key for key in keys if key not in ["parameters", "cv_scores", "warnings"]]
        cost_keys = [key for key in keys if key.endswith("_seconds") or
                     key.startswith("virtual_") or key.endswith("token_positions")]
        intervals = {key: _interval([row[key] for row in rows], seed + 100 + number, frozen)
                     for key in keys if key not in cost_keys}
        methods[method] = {key: interval["mean"] for key, interval in intervals.items()}
        for key in cost_keys:
            values = [row[key] for row in rows]
            methods[method][key] = None if any(v is None for v in values) else float(np.mean(values))
        methods[method]["conditional_intervals"] = intervals
        methods[method]["by_domain"] = {}
        for domain in rows[0]["by_domain"]:
            keys_domain = list(rows[0]["by_domain"][domain])
            domain_intervals = {key: _interval([row["by_domain"][domain][key] for row in rows],
                                               seed + 200 + number, frozen)
                                for key in keys_domain if not key.endswith("token_positions")}
            methods[method]["by_domain"][domain] = {
                **{key: interval["mean"] for key, interval in domain_intervals.items()},
                "conditional_intervals": domain_intervals}
            for key in keys_domain:
                if key.endswith("token_positions"):
                    methods[method]["by_domain"][domain][key] = float(np.mean([row["by_domain"][domain][key] for row in rows]))
    return methods


def _plots(output, summary, records):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError as error:
        return {"status": "unavailable", "reason": str(error), "files": []}
    plt.rcParams.update({"font.size": 10, "axes.spines.top": False,
                         "axes.spines.right": False, "figure.dpi": 140})
    names = [NAMES[m] for m in METHODS]
    values = [summary["methods"][m]["next_top10_recall"] for m in METHODS]
    ci = [summary["methods"][m]["conditional_intervals"]["next_top10_recall"]["conditional_95"] for m in METHODS]
    x = np.arange(len(METHODS))
    fig, ax = plt.subplots(figsize=(8.2, 4.6))
    for row in records:
        ax.scatter(x, [row["methods"][m]["next_top10_recall"] for m in METHODS],
                   s=13, alpha=.18, color="#475569", zorder=1)
    ax.errorbar(x, values, yerr=np.array([[v - bounds[0], bounds[1] - v] for v, bounds in zip(values, ci)]).T,
                fmt="o", capsize=5, color="#2563eb", lw=2, zorder=3)
    ax.axhline(10 / 68, color="#b45309", ls="--", lw=1.4,
               label="Exact random expectation: 10/68")
    ax.set_xticks(x, names, rotation=15)
    ax.set_ylim(0, min(1.05, max(max(values) + .18, .45)))
    ax.set_ylabel("Macro recall of next top10")
    ax.set_title("Fresh pool: 20 fixed-pool selection seeds")
    ax.grid(axis="y", alpha=.18)
    ax.legend(frameon=False, loc="upper right")
    fig.text(.5, .015, "Points: seeds; bars: conditional 95% bootstrap. One corpus, not 20 independent corpora.",
             ha="center", fontsize=8)
    fig.tight_layout(rect=(0, .05, 1, 1))
    first = output / "next_top10_recall.png"
    fig.savefig(first, bbox_inches="tight")
    plt.close(fig)

    keys = ["krr_minus_random_expectation", "krr_minus_gp", "gp_minus_random_expectation",
            "krr_minus_bayesian_ridge", "krr_minus_cluster_mean"]
    labels = ["KRR - exact random", "KRR - GP", "GP - exact random", "KRR - Bayesian ridge", "KRR - cluster mean"]
    comparisons = [summary["comparisons"][key] for key in keys]
    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    for index, interval in enumerate(comparisons):
        lower, upper = interval["conditional_95"]
        ax.plot([lower, upper], [index, index], color="#2563eb", lw=2)
        ax.plot(interval["mean"], index, "o", color="#2563eb")
    ax.axvline(0, color="#64748b", lw=1)
    margin = summary["declared_noninferiority_margin"]
    # This margin applies only to KRR-GP, indicated on its own row.
    ax.plot([-margin, -margin], [.78, 1.22], color="#b45309", lw=3,
            label="KRR-GP declared threshold: -1/60")
    ax.set_yticks(range(len(labels)), labels)
    ax.invert_yaxis()
    ax.set_xlabel("Paired difference in macro next-top10 recall")
    ax.set_title("Predeclared primary/secondary and descriptive contrasts")
    ax.grid(axis="x", alpha=.18)
    ax.legend(frameon=False, loc="upper left", bbox_to_anchor=(0, -.17), borderaxespad=0)
    fig.text(.5, .015, "95% intervals are conditional on this pool; descriptive controls are not multiplicity-adjusted.",
             ha="center", fontsize=8)
    fig.tight_layout(rect=(0, .11, 1, 1))
    second = output / "paired_recall_differences.png"
    fig.savefig(second, bbox_inches="tight")
    plt.close(fig)
    return {"status": "created", "files": [{"filename": path.name, "sha256": _sha(path)}
                                              for path in [first, second]]}


def _fmt(value, digits=4):
    return "не определено" if value is None else f"{value:.{digits}f}"


def _ci(interval):
    if interval["conditional_95"] is None:
        return "не определён"
    return "[" + "; ".join(_fmt(v) for v in interval["conditional_95"]) + "]"


def _report(output, summary):
    primary = summary["primary"]
    secondary = summary["secondary_noninferiority"]
    decisions = {
        "positive_search_signal_on_this_fresh_pool": "Положительный поисковый сигнал KRR на этом свежем пуле подтверждён по заранее заданному правилу.",
        "worse_than_random_expectation_on_this_fresh_pool": "KRR уступает точному ожиданию случайного отбора на этом свежем пуле.",
        "inconclusive_search_signal_on_this_fresh_pool": "Первичная проверка KRR против точного ожидания случайного отбора не дала определённого результата."}
    tolerances = {
        "supports_declared_tolerance": "Нижняя граница интервала KRR−GP выше −1/60: данные поддерживают заранее объявленный допуск.",
        "worse_than_declared_tolerance": "Верхняя граница интервала KRR−GP ниже −1/60: KRR уступает GP сильнее объявленного допуска.",
        "inconclusive_declared_tolerance": "Интервал KRR−GP пересекает порог −1/60: результат по объявленному допуску неопределён."}
    lines = ["# Результаты свежего подтверждения гибридного отбора", "",
             decisions[primary["decision"]], "", tolerances[secondary["decision"]], "",
             "Один свежий пул содержит 600 документов: 6 доменов по 100. Для каждого из 20 заранее заданных seeds 100…119 берутся SRS32/домен (192 метки), затем каждый метод выбирает 10 из оставшихся 68/домен (60 документов). Это условные повторения планов отбора на одном корпусе, а не 20 независимых корпусов.", "",
             f"Объединение initial-наборов всех seeds содержит {summary['initial_union_documents']} документов и измеряется до отбора. Оно может включать весь пул600. Каждый вызов обучения получает только собственные 192 метки; полная агрегация oracle600 создаётся после сохранения всех next60. Разделение доступа программное, не криптографическое: физические файлы измерений могут уже существовать, а SHA256 проверяет их неизменность, не скрывает метки.", "",
             "Первичная метрика — средний по шести доменам recall истинного top10 в общем остатке. Для случайного отбора точное ожидание равно 10/68 = " + _fmt(10 / 68, 6) + ". Первичный контраст KRR−10/68: " + _fmt(primary["mean"]) + "; условный 95% bootstrap-интервал " + _ci(primary) + ". Положительный результат требует строго нижней границы > 0.", "",
             "Вторичная заранее заданная проверка KRR−GP: " + _fmt(secondary["mean"]) + "; интервал " + _ci(secondary) + ". Допуск 1/60 = " + _fmt(summary["declared_noninferiority_margin"], 6) + " соответствует одному документу из совокупного next60. Правило поддержки допуска: нижняя граница > −1/60. Пересечение интервалов отдельных методов не является доказательством равенства.", "",
             "## Метрики отбора и предсказания", "",
             "| Метод | Next top10 recall | Условный 95% интервал | Top10 полного пула после252 | Средний JSD next60 | MAE остатка408 | R² остатка408 | Spearman остатка408 | Худший regret JSD |",
             "|---|---:|---|---:|---:|---:|---:|---:|---:|"]
    for method in METHODS:
        row = summary["methods"][method]
        lines.append("| " + NAMES[method] + " | " + " | ".join([
            _fmt(row["next_top10_recall"]), _ci(row["conditional_intervals"]["next_top10_recall"]),
            _fmt(row["full_top10_recall_after_252"]), _fmt(row["mean_new_jsd"]),
            _fmt(row.get("unselected_mae")), _fmt(row.get("unselected_r2")),
            _fmt(row.get("remaining_spearman")), _fmt(row["worst_domain_jsd_regret"])]) + " |")
    lines += ["", "MAE/R²/Spearman оцениваются на общих оставшихся 408 документах до приобретения next60. Regret JSD домена — средний JSD его истинного оставшегося top10 минус средний JSD выбранных 10; показан максимум по доменам, затем среднее по seeds. Константные оценки или истинные значения дают Spearman=null, а не исключённую строку. R² при константной цели также null. Полные результаты каждого домена и seed сохранены в JSON.", "",
              "## Парные сравнения", "",
              "Все интервалы используют 10 000 bootstrap-перевыборок seeds при фиксированном пуле. Дополнительные сравнения описательные, без поправки на множественность.", "",
              "| Контраст next-top10 recall | Среднее | Условный 95% интервал |",
              "|---|---:|---|"]
    for name, interval in summary["comparisons"].items():
        if "theta" not in name:
            lines.append(f"| {name} | {_fmt(interval['mean'])} | {_ci(interval)} |")
    lines += ["", "## Карта долей θ", "",
              "θ домена — доля документов с JSD ≤ " + str(summary["epsilon"]) + ". Для гибрида она оценивается только по SRS32/домен (192 метки); поисковые 60 не добавляются в эту оценку. Случайный компаратор использует SRS42/домен (252 метки). Истина — все 100 документов домена.", "",
              "| Оценка | Средняя абсолютная ошибка θ, п.п. | Условный 95% интервал | Spearman ранга 6 доменов | Точность выбора худшего домена | Regret θ выбранного домена |",
              "|---|---:|---|---:|---:|---:|"]
    for key, label in [("initial192", "Гибрид: SRS192"), ("random252", "Случайный: SRS252")]:
        item = summary["theta"][key]
        lines.append(f"| {label} | {_fmt(item['error_pp']['mean'])} | {_ci(item['error_pp'])} | {_fmt(item['domain_rank_spearman']['mean'])} | {_fmt(item['worst_domain_correct']['mean'])} | {_fmt(item['worst_domain_regret']['mean'])} |")
    lines += ["", "Худший домен имеет минимальную оценку θ; при равенстве оценок выбирается первый по имени домена. Выбор любого домена, делящего истинный минимум θ, считается правильным. Regret θ равен истинной θ выбранного домена минус минимальная истинная θ (доли от 0 до 1). Условные интервалы точности и regret сохранены в JSON.", "",
              "При константном ранге θ корреляция не определена и сохранена как null. Если хотя бы один seed даёт null, среднее и интервал полной серии тоже null; число таких seeds указано в JSON. Это сохраняет все 20 планов, не отбрасывая неудобные случаи.", "",
              "## Измеренная стоимость", "",
              f"Физически измерен полный Qwen oracle600: {summary['physical_costs']['oracle_documents']} документов, {summary['physical_costs']['qwen_token_positions']} оцениваемых токеновых позиций, сумма записанных времён Qwen {_fmt(summary['physical_costs']['qwen_recorded_seconds'], 2)} с. Виртуальный бюджет каждого метода равен 252 документам. Сумма времён документов — записанное время forward двух Qwen и JSD по документам, включая возможный прогрев первых проходов; это не полное wall-clock время запуска Colab, загрузки моделей, BGE, файлового ввода/вывода или всей процедуры.", "",
              "Фиксированная подготовка BGE для всех 600 документов: " + _fmt(summary["bge_fixed_cost"]["seconds"], 2) + " с (загрузка " + _fmt(summary["bge_fixed_cost"]["bge_model_loading_seconds"], 2) + ", embeddings " + _fmt(summary["bge_fixed_cost"]["bge_embedding_seconds"], 2) + "). Она учитывается один раз для GP/KRR/Bayesian ridge/Cluster mean, не умножается на 20 seeds. Domain mean использует доменные метки без BGE; случайный отбор BGE также не требует. Полная подготовка корпуса занимает отдельно " + _fmt(summary["bge_fixed_cost"]["all_preparation_seconds"], 2) + " с и не прибавляется повторно к BGE. Время CPU взято только из сохранённых записей обучения, предсказания и выбора; оценщик ничего не переобучает. Незаписанное время случайного выбора остаётся null. Для времени CPU и токеновых затрат приводятся описательные средние без bootstrap-интервалов.", "",
              "| Метод | Qwen initial192, с | Qwen next60, с | Qwen virtual252, с | Токеновые позиции252 | Fit CPU, с | Predict CPU, с | Select CPU, с | BGE600, с |",
              "|---|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for method in METHODS:
        row = summary["methods"][method]
        keys = ["qwen_initial_recorded_seconds", "qwen_next_recorded_seconds", "qwen_virtual252_recorded_seconds",
                "total_token_positions", "fit_seconds", "prediction_seconds", "selection_seconds", "bge_fixed600_seconds"]
        lines.append("| " + NAMES[method] + " | " + " | ".join(_fmt(row.get(k), 2) for k in keys) + " |")
    lines += ["", "Равное число документов не означает равное число токенов или одинаковое GPU-время. Таблица содержит среднее по виртуальным планам, а не сумму затрат 20 независимых измерений oracle.", "",
              "## Воспроизводимый порядок", "", "```text",
              "зафиксировать study, свежий corpus600 и планы seeds100…119",
              "подготовить BGE600; измерить только объединение разрешённых initial192",
              "для каждого seed: обучить 5 методов только на его initial192",
              "сохранить mu, next60, исходные train_y и CPU-времена; записать SHA256 seal",
              "после фиксации всех next60 дополнить Qwen oracle до600",
              "проверить seal; независимо пересчитать oracle по600 физическим exact-векторам",
              "сверить token IDs/counts/Qwen time и train_y с oracle[initial]",
              "посчитать recall/MAE/R²/rank/θ/cost; условно bootstrap по20 seeds",
              "применить первичное правило lower(KRR−10/68)>0 и допуск lower(KRR−GP)>−1/60",
              "```", "",
              "Высокий JSD и успешный поиск не доказывают полезность примеров для обучения студента: студент здесь не обучается. Вывод ограничен этим свежим пулом, одной следующей порцией и зафиксированными методами. Условные интервалы не измеряют перенос на новые корпуса и не дают автоматического разрешения на внедрение.", "",
              "## Источники и контроль целостности", "",
              "Все обязательные файлы плана, признаков, выбора, CPU-времён, oracle и 600 физических измерений прошли SHA256-проверку. Независимая сверка всех600 NPZ подтвердила точное совпадение oracle.y со средним физического exact-вектора, числа токеновых позиций и записанных Qwen-времён; sample IDs следуют порядку pool.jsonl, а token IDs совпадают с зафиксированным alignment. Исходные train_y каждого seed точно совпадают с соответствующими 192 значениями полного oracle. Оценщик загружает oracle после проверки фиксации выборов. Хэши ниже позволяют проверить использованные файлы; сами по себе они не заменяют аудит порядка стадий.", "",
              "| Файл | SHA256 |", "|---|---|"]
    for filename, digest in sorted(summary["provenance"]["sources_sha256"].items()):
        if not filename.startswith("data/measurements/"):
            lines.append(f"| `{filename}` | `{digest}` |")
    lines += ["", "Имена и SHA256 всех 600 файлов `data/measurements/*.npz` приведены в `summary.json` (`provenance.sources_sha256` и `provenance.selection_seal.verified_files`) и исходном `data/oracle_seal.json`."]
    if summary["plots"]["status"] == "created":
        lines += ["", "![Recall и условные интервалы](next_top10_recall.png)", "",
                  "![Парные разности](paired_recall_differences.png)"]
    else:
        lines += ["", "PNG-графики не созданы: " + summary["plots"].get("reason", "неизвестная причина")]
    (output / "РЕЗУЛЬТАТЫ.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def evaluate(root, study):
    """Verify sealed choices and evaluate the complete oracle; never refit."""
    started = time.perf_counter()
    root = Path(root).resolve()
    seeds = list(study["seeds"])
    _require(seeds == list(range(100, 120)), "Confirmation requires frozen seeds 100..119")
    epsilon = float(study["epsilon"])
    _require(epsilon == .05, "Confirmation epsilon must remain .05")
    bootstrap_seed = int(study["bootstrap_seed"])
    margin = float(study["noninferiority_margin"])
    _require(math.isclose(margin, 1 / 60, abs_tol=1e-15), "Declared margin must remain 1/60")
    if "bootstrap_repetitions" in study:
        _require(study["bootstrap_repetitions"] == 10000, "Frozen bootstrap uses 10000 repetitions")
    seal = _verify_seal(root, study, seeds)
    frozen = _frozen(root)
    with np.load(root / "data" / "features.npz", allow_pickle=False) as data:
        X, ids, domains = data["X"], data["ids"].astype(str), data["domains"].astype(str)
    with np.load(root / "data" / "oracle.npz", allow_pickle=False) as data:
        y, counts, qwen = np.asarray(data["y"], dtype=float), data["token_counts"], np.asarray(data["qwen_seconds"], dtype=float)
        _require(np.array_equal(ids, data["ids"].astype(str)), "Oracle/feature IDs differ")
        _require(np.array_equal(domains, data["domains"].astype(str)), "Oracle/feature domains differ")
    n = len(y)
    unique_domains = sorted(set(domains.tolist()))
    _require(n == 600 and X.ndim == 2 and X.shape[0] == n and len(ids) == n and len(domains) == n,
             "Expected complete 600-row feature/oracle alignment")
    _require(len(unique_domains) == 6 and all(np.sum(domains == d) == 100 for d in unique_domains),
             "Expected six domains with exactly 100 documents each")
    _require(len(set(ids.tolist())) == n, "Sample IDs must be unique")
    _require(y.shape == (n,) and np.all(np.isfinite(y)) and np.all(y >= 0), "Invalid complete oracle labels")
    _require(np.all(np.isfinite(X)), "Nonfinite features")
    _require(counts.shape == (n,) and np.issubdtype(counts.dtype, np.integer) and np.all(counts >= 0),
             "Invalid measured token counts")
    _require(qwen.shape == (n,) and np.all(np.isfinite(qwen)) and np.all(qwen >= 0),
             "Invalid measured per-document Qwen timings")
    _require(int(counts.sum()) == seal["oracle_total_positions"], "Token positions differ from oracle seal")
    physical_oracle = _verify_physical_oracle(root, seal, y, ids, domains, counts, qwen)
    plans = _read(root / "data" / "plans.json")
    truth = frozen.theta_estimate(y, domains, np.arange(n), epsilon)
    true_rank = [truth[d] for d in unique_domains]
    bge = _bge_cost(root)
    records = []
    for seed in seeds:
        choices_path = root / "choices" / f"seed_{seed}_choices.npz"
        fit_path = root / "choices" / f"seed_{seed}_fit.json"
        fits = _fit_records(fit_path)
        with np.load(choices_path, allow_pickle=False) as choices:
            initial = _indices(choices["initial"], n, "initial")
            remaining = _indices(choices["remaining"], n, "remaining")
            random_chosen = _indices(choices["random_chosen"], n, "random_chosen")
            _require(np.array_equal(initial, np.asarray(plans[str(seed)]["initial"], dtype=int)), "Initial indices differ from frozen plan")
            planned_random = plans[str(seed)]["random_next"]
            _require(np.array_equal(random_chosen, np.asarray(planned_random, dtype=int)), "Random choices differ from frozen plan")
            _require(len(initial) == 192 and len(remaining) == 408 and
                     np.array_equal(np.sort(remaining), np.setdiff1d(np.arange(n), initial)),
                     "Initial/remaining partition differs from 192/408 plan")
            _require(all(np.sum(domains[initial] == d) == 32 for d in unique_domains), "Initial plan is not SRS32/domain")
            train_y = np.asarray(choices["train_y"], dtype=float)
            _require(train_y.shape == (192,) and np.array_equal(train_y, y[initial]), "Saved train_y differs from oracle initial192")
            initial_theta = frozen.theta_estimate(y, domains, initial, epsilon)
            random_theta = frozen.theta_estimate(y, domains, np.r_[initial, random_chosen], epsilon)
            record = {"seed": seed, "choices_sha256": _sha(choices_path), "fit_sha256": _sha(fit_path),
                      "train_y_equals_oracle_initial192": True,
                      "train_label_sha256": hashlib.sha256(train_y.tobytes()).hexdigest(),
                      "theta_initial192": initial_theta, "theta_random252": random_theta,
                      "theta_initial192_error_pp": frozen.theta_error(initial_theta, truth),
                      "theta_random252_error_pp": frozen.theta_error(random_theta, truth),
                      "theta_initial192_domain_rank_spearman": _rank([initial_theta[d] for d in unique_domains], true_rank),
                      "theta_random252_domain_rank_spearman": _rank([random_theta[d] for d in unique_domains], true_rank),
                      "methods": {}}
            for key, estimate in [("initial192", initial_theta), ("random252", random_theta)]:
                worst = _theta_worst(estimate, truth)
                record["theta_" + key + "_worst_domain"] = worst["domain"]
                record["theta_" + key + "_worst_domain_correct"] = worst["correct"]
                record["theta_" + key + "_worst_domain_regret"] = worst["regret"]
            for method in METHODS:
                chosen = random_chosen if method == "random" else _indices(choices[method + "_chosen"], n, method + "_chosen")
                _require(len(chosen) == 60 and np.all(np.isin(chosen, remaining)) and
                         all(np.sum(domains[chosen] == d) == 10 for d in unique_domains),
                         method + " must choose ten distinct remaining documents per domain")
                mu = None if method == "random" else np.asarray(choices[method + "_mu"], dtype=float)
                if mu is not None:
                    _require(mu.shape == (n,) and np.all(np.isfinite(mu)), "Invalid saved predictions for " + method)
                    expected_chosen = np.concatenate([frozen.top_indices(remaining[domains[remaining] == d], mu, ids, 10)
                                                      for d in unique_domains])
                    _require(np.array_equal(chosen, expected_chosen), "Saved choices do not match frozen top10 rule: " + method)
                record["methods"][method] = _metrics(frozen, y, domains, ids, counts, initial, remaining,
                    chosen, mu, qwen, fits.get(method), bge, method)
            records.append(record)

    methods = _aggregate(records, bootstrap_seed, frozen)
    comparisons = {}
    for number, method in enumerate(PREDICTORS):
        comparisons[method + "_minus_random_expectation"] = _interval(
            [r["methods"][method]["next_top10_recall"] - 10 / 68 for r in records],
            bootstrap_seed if method == "krr" else bootstrap_seed + number + 1, frozen)
        comparisons[method + "_minus_random_draw"] = _interval(
            [r["methods"][method]["next_top10_recall"] - r["methods"]["random"]["next_top10_recall"] for r in records],
            bootstrap_seed + 10 + number, frozen)
    for number, control in enumerate(["gp", "bayesian_ridge", "cluster_mean", "domain_mean"]):
        comparisons["krr_minus_" + control] = _interval(
            [r["methods"]["krr"]["next_top10_recall"] - r["methods"][control]["next_top10_recall"] for r in records],
            bootstrap_seed + 20 + number, frozen)
    for number, control in enumerate(["bayesian_ridge", "cluster_mean", "domain_mean"]):
        comparisons["gp_minus_" + control] = _interval(
            [r["methods"]["gp"]["next_top10_recall"] - r["methods"][control]["next_top10_recall"] for r in records],
            bootstrap_seed + 25 + number, frozen)
    comparisons["random252_theta_error_minus_initial192_pp"] = _interval(
        [r["theta_random252_error_pp"] - r["theta_initial192_error_pp"] for r in records], bootstrap_seed + 30, frozen)
    primary = dict(comparisons["krr_minus_random_expectation"])
    low, high = primary["conditional_95"]
    primary["decision"] = ("positive_search_signal_on_this_fresh_pool" if low > 0 else
        "worse_than_random_expectation_on_this_fresh_pool" if high < 0 else "inconclusive_search_signal_on_this_fresh_pool")
    primary["contrast"] = "krr_minus_exact_random_expectation"
    primary["rule"] = "conditional_95 lower > 0"
    secondary = dict(comparisons["krr_minus_gp"])
    low, high = secondary["conditional_95"]
    secondary["decision"] = ("supports_declared_tolerance" if low > -margin else
        "worse_than_declared_tolerance" if high < -margin else "inconclusive_declared_tolerance")
    secondary.update(contrast="krr_minus_gp", margin=margin,
                     rule="lower > -margin supports tolerance; upper < -margin is worse; otherwise inconclusive")
    theta = {"truth": truth}
    for number, key in enumerate(["initial192", "random252"]):
        theta[key] = {"error_pp": _interval([r["theta_" + key + "_error_pp"] for r in records], bootstrap_seed + 40 + number, frozen),
                      "domain_rank_spearman": _interval([r["theta_" + key + "_domain_rank_spearman"] for r in records], bootstrap_seed + 42 + number, frozen),
                      "worst_domain_correct": _interval([r["theta_" + key + "_worst_domain_correct"] for r in records], bootstrap_seed + 46 + number, frozen),
                      "worst_domain_regret": _interval([r["theta_" + key + "_worst_domain_regret"] for r in records], bootstrap_seed + 48 + number, frozen),
                      "by_domain": {d: _interval([r["theta_" + key][d] for r in records], bootstrap_seed + 44 + number, frozen)
                                    for d in unique_domains}}
    output = root / "results"
    output.mkdir(exist_ok=True)
    summary = {"status": "completed", "scope": "fresh600 confirmation conditional on one fixed corpus",
               "seed_count": len(seeds), "seeds": seeds, "domains": unique_domains,
               "initial_union_documents": len({i for plan in plans.values() for i in plan["initial"]}),
               "epsilon": epsilon, "exact_random_expected_recall": 10 / 68,
               "declared_noninferiority_margin": margin, "primary": primary,
               "secondary_noninferiority": secondary,
               "both_predeclared_gates_supported": primary["decision"] == "positive_search_signal_on_this_fresh_pool" and secondary["decision"] == "supports_declared_tolerance",
               "methods": methods, "comparisons": comparisons, "theta": theta,
               "theta_initial192_error_pp": theta["initial192"]["error_pp"]["mean"],
               "theta_random252_error_pp": theta["random252"]["error_pp"]["mean"],
               "bge_fixed_cost": bge,
               "physical_costs": {"oracle_documents": n, "qwen_token_positions": int(counts.sum()),
                   "qwen_recorded_seconds": float(qwen.sum()), "bge_documents": n,
                   "bge_recorded_seconds": bge["seconds"],
                   "meaning": "Physical oracle600, with sums of recorded per-document Qwen+JSD times, including possible initial warmup; not full run wall clock"},
               "provenance": {"python": platform.python_version(), "numpy": np.__version__,
                   "selection_seal": seal, "sources_sha256": _sources(root, seal),
                   "physical_oracle_reconstruction": physical_oracle,
                   "all_20_train_y_equal_oracle_initial192": True, "evaluator_fits": 0,
                   "access_separation": "Programmatic seed-specific label interface, not cryptographic isolation",
                   "bootstrap_repetitions": 10000, "bootstrap_seed": bootstrap_seed},
               "limitations": ["20 seeds are conditional repetitions on one corpus, not independent corpora.",
                   "Descriptive controls are not multiplicity-adjusted; overlapping intervals do not establish equality.",
                   "Physical oracle600 and virtual252 selection trajectories have distinct costs.",
                   "Recorded Qwen times are per-document measurements, possibly including initial warmup; not full run wall-clock time.",
                   "Undefined Spearman/R2 values remain null; undefined seeds are not silently dropped.",
                   "High JSD or top10 recall does not prove usefulness for student learning.",
                   "This one-batch confirmation does not establish generalization to other corpora or automatic deployment."]}
    summary["plots"] = _plots(output, summary, records)
    summary["evaluation_seconds"] = time.perf_counter() - started
    _write(output / "seed_results.json", records)
    _write(output / "summary.json", summary)
    _report(output, summary)
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    result = evaluate(args.root, _read(args.root / "study.json"))
    print(json.dumps({"status": result["status"], "primary": result["primary"]["decision"],
                      "secondary": result["secondary_noninferiority"]["decision"]}, ensure_ascii=False))
