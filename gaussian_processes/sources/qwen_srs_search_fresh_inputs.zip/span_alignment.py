"""Align new inputs using raw text and verified tokenizer boundaries.

Never reconstruct text by decoding truncated IDs.  A raw prefix is usable only
when its *untruncated* Qwen tokenization is exactly a prefix of the original
Qwen input IDs.  If a byte token boundary cuts a Unicode character, keeping the
same target is impossible: strict alignment rejects it, while joint alignment
explicitly prepares a shorter input that must be measured again.

This module does not change the frozen MMLU product or reuse old labels.
"""
from dataclasses import dataclass
from hashlib import sha256
import json
from typing import Any


class UnsafePrefixBoundary(ValueError):
    """No raw prefix represents the requested Qwen IDs without changing them."""


def _encode(tokenizer, text, *, special=False, limit=None):
    if not getattr(tokenizer, "is_fast", False):
        raise ValueError("Raw-prefix alignment requires a fast tokenizer with character offsets")
    options = dict(add_special_tokens=special, truncation=limit is not None,
                   return_offsets_mapping=True, return_special_tokens_mask=True,
                   verbose=False)
    if limit is not None:
        options["max_length"] = limit
    result = tokenizer(text, **options)
    ids = tuple(int(v) for v in result["input_ids"])
    offsets = tuple((int(a), int(b)) for a, b in result["offset_mapping"])
    mask = tuple(int(v) for v in result["special_tokens_mask"])
    if len(ids) != len(offsets) or len(ids) != len(mask):
        raise ValueError("Tokenizer IDs, offsets and special-token mask are not aligned")
    for (start, end), is_special in zip(offsets, mask):
        if not is_special and not (0 <= start < end <= len(text)):
            raise ValueError("Tokenizer returned an invalid raw character span")
    if not special and any(mask):
        raise ValueError("Qwen input unexpectedly contains inserted special tokens")
    return dict(ids=ids, offsets=offsets, special=mask)


def _merged_intervals(offsets):
    merged = []
    for start, end in sorted(offsets):
        if merged and start <= merged[-1][1]:
            merged[-1][1] = max(end, merged[-1][1])
        else:
            merged.append([start, end])
    return merged


def encoder_coverage(raw_prefix, encoder_tokenizer, *, max_length=256,
                     qwen_offsets=()):
    """Describe encoder truncation; whitespace gaps are reported separately.

    ``input_token_coverage == 1`` means the complete encoder token sequence,
    including its special tokens, was supplied.  Character-offset coverage can
    be lower because tokenizers omit whitespace or normalize characters even
    when they see the complete raw input.
    """
    full = _encode(encoder_tokenizer, raw_prefix, special=True)
    seen = _encode(encoder_tokenizer, raw_prefix, special=True, limit=max_length)
    full_content = sum(not s for s in full["special"])
    seen_content = sum(not s for s in seen["special"])
    spans = [span for span, s in zip(seen["offsets"], seen["special"]) if not s]
    merged = _merged_intervals(spans)
    covered_characters = sum(end - start for start, end in merged)
    end = max((b for _, b in spans), default=0)
    complete = full["ids"] == seen["ids"]
    overlap_positions, fully_covered_positions = 0, 0
    for start, stop in qwen_offsets:
        overlap = sum(max(0, min(stop, b) - max(start, a)) for a, b in merged)
        overlap_positions += overlap > 0
        fully_covered_positions += overlap == stop - start
    return dict(max_length=int(max_length), total_tokens=len(full["ids"]),
        seen_tokens=len(seen["ids"]), total_content_tokens=full_content,
        seen_content_tokens=seen_content, still_truncated=not complete,
        full_input_token_sequence_seen=complete,
        input_token_coverage=1.0 if complete else seen_content / max(full_content, 1),
        raw_input_characters=len(raw_prefix), last_content_character_end=end,
        prefix_character_end_coverage=end / max(len(raw_prefix), 1),
        offset_union_characters=covered_characters,
        offset_union_character_coverage=covered_characters / max(len(raw_prefix), 1),
        qwen_positions=len(qwen_offsets),
        qwen_positions_with_character_overlap=overlap_positions,
        qwen_positions_fully_covered_by_offsets=fully_covered_positions,
        input_has_tail_beyond_qwen_prefix=False,
        truncation_side=getattr(encoder_tokenizer, "truncation_side", "right"))


@dataclass(frozen=True)
class AlignedPrefix:
    raw_prefix: str
    raw_end: int
    input_ids: tuple[int, ...]
    offsets: tuple[tuple[int, int], ...]
    original_input_ids: tuple[int, ...]
    original_offsets: tuple[tuple[int, int], ...]
    source_characters: int
    source_sha256: str
    original_full_qwen_tokens: int
    qwen_max_length: int
    trim_reasons: tuple[str, ...]
    teacher_verified: bool
    encoder_metadata: dict[str, Any] | None = None

    def metadata(self):
        changed = self.input_ids != self.original_input_ids
        return dict(alignment_version="verified_raw_joint_prefix_v1",
            raw_end=self.raw_end, original_qwen_character_end=max(b for _, b in self.original_offsets),
            source_characters=self.source_characters, source_sha256=self.source_sha256,
            raw_prefix_sha256=sha256(self.raw_prefix.encode("utf-8")).hexdigest(),
            qwen_max_length=self.qwen_max_length,
            original_full_qwen_tokens=self.original_full_qwen_tokens,
            original_qwen_seen_tokens=len(self.original_input_ids),
            aligned_qwen_tokens=len(self.input_ids),
            trimmed_qwen_tokens=len(self.original_input_ids) - len(self.input_ids),
            original_input_ids=list(self.original_input_ids), aligned_input_ids=list(self.input_ids),
            original_offsets=[list(v) for v in self.original_offsets],
            aligned_offsets=[list(v) for v in self.offsets],
            aligned_ids_sha256=sha256(json.dumps(self.input_ids).encode()).hexdigest(),
            qwen_input_ids_changed=changed, trim_reasons=list(self.trim_reasons),
            raw_prefix_retokenization_verified=True, teacher_verified=self.teacher_verified,
            label_action="remeasure_on_aligned_input_ids" if changed else "same_input_ids",
            encoder=self.encoder_metadata)


def _align(text, qwen_tokenizer, *, teacher_tokenizer, max_length,
           allow_boundary_trim, encoder_tokenizer, encoder_max_length,
           min_qwen_tokens, strip_stable):
    if getattr(qwen_tokenizer, "truncation_side", "right") != "right":
        raise ValueError("Qwen must truncate on the right to define a raw prefix")
    full = _encode(qwen_tokenizer, text)
    original = _encode(qwen_tokenizer, text, limit=max_length)
    if not original["ids"]:
        raise UnsafePrefixBoundary("Qwen input has no content tokens")
    if original["ids"] != full["ids"][:max_length]:
        raise ValueError("Qwen truncation does not preserve the original token prefix")
    if teacher_tokenizer is not None:
        teacher = _encode(teacher_tokenizer, text, limit=max_length)
        if teacher["ids"] != original["ids"]:
            raise ValueError("Teacher and student tokenize the original input differently")
    original_end = max(end for _, end in original["offsets"])
    boundary_needs_trim, encoder_needs_trim, strip_needs_trim = False, False, False
    for end in sorted({end for _, end in original["offsets"]}, reverse=True):
        prefix = text[:end]
        candidate = _encode(qwen_tokenizer, prefix)
        count = len(candidate["ids"])
        exact = (min_qwen_tokens <= count <= len(original["ids"])
                 and candidate["ids"] == original["ids"][:count]
                 and candidate["offsets"] == original["offsets"][:count]
                 and max((b for _, b in candidate["offsets"]), default=0) == end)
        if end == original_end and not exact:
            boundary_needs_trim = True
        if not exact:
            continue
        if candidate["ids"] != original["ids"] and not allow_boundary_trim:
            raise UnsafePrefixBoundary(
                f"No raw prefix represents all {len(original['ids'])} truncated Qwen IDs; "
                f"the closest safe prefix has {count}. Prepare a new input and remeasure its JSD.")
        if encoder_tokenizer is not None:
            encoded = _encode(encoder_tokenizer, prefix, special=True)
            if len(encoded["ids"]) > encoder_max_length:
                encoder_needs_trim = True
                continue
        if strip_stable and prefix != prefix.strip():
            strip_needs_trim = True
            continue
        if teacher_tokenizer is not None:
            teacher = _encode(teacher_tokenizer, prefix)
            if teacher["ids"] != candidate["ids"]:
                raise ValueError("Teacher and student tokenize the aligned input differently")
        coverage = None
        if encoder_tokenizer is not None:
            coverage = encoder_coverage(prefix, encoder_tokenizer,
                max_length=encoder_max_length, qwen_offsets=candidate["offsets"])
            if not coverage["full_input_token_sequence_seen"]:
                raise ValueError("The selected joint prefix was still truncated by the encoder")
        reasons = []
        if len(full["ids"]) > max_length:
            reasons.append("qwen_token_limit")
        if boundary_needs_trim:
            reasons.append("qwen_raw_boundary")
        if encoder_needs_trim:
            reasons.append("encoder_token_limit")
        if strip_needs_trim:
            reasons.append("canonical_strip_boundary")
        return AlignedPrefix(raw_prefix=prefix, raw_end=end, input_ids=candidate["ids"],
            offsets=candidate["offsets"], original_input_ids=original["ids"],
            original_offsets=original["offsets"], source_characters=len(text),
            source_sha256=sha256(text.encode("utf-8")).hexdigest(),
            original_full_qwen_tokens=len(full["ids"]), qwen_max_length=max_length,
            trim_reasons=tuple(reasons), teacher_verified=teacher_tokenizer is not None,
            encoder_metadata=coverage)
    raise UnsafePrefixBoundary(
        f"No verified raw prefix meets Qwen/encoder limits and min_qwen_tokens={min_qwen_tokens}")


def align_raw_prefix(text, qwen_tokenizer, *, teacher_tokenizer=None,
                     max_length=256, allow_boundary_trim=False):
    """Align a Qwen-only raw span; strict mode preserves the existing target.

    ``allow_boundary_trim=True`` is only for preparing a new input before JSD
    measurement.  Old labels must not be retained if ``input_ids`` changed.
    """
    return _align(text, qwen_tokenizer, teacher_tokenizer=teacher_tokenizer,
        max_length=max_length, allow_boundary_trim=allow_boundary_trim,
        encoder_tokenizer=None, encoder_max_length=256, min_qwen_tokens=1,
        strip_stable=False)


def choose_joint_prefix(text, qwen_tokenizer, encoder_tokenizer, *,
                        teacher_tokenizer=None, qwen_max_length=256,
                        encoder_max_length=256, min_qwen_tokens=1,
                        strip_stable=False):
    """Prepare a new natural input fully seen by both models.

    Select the maximum raw character endpoint that preserves the original
    Qwen token prefix and fits the complete encoder token sequence, including
    special tokens.  Compute a new JSD on returned ``input_ids``; never attach
    labels measured on the longer source input.

    ``strip_stable=True`` is useful for callers whose pool canonicalization
    strips texts: strip the source before calling, then this option chooses a
    boundary that survives that operation unchanged.  It never strips a
    returned prefix after its IDs have been verified.
    """
    return _align(text, qwen_tokenizer, teacher_tokenizer=teacher_tokenizer,
        max_length=qwen_max_length, allow_boundary_trim=True,
        encoder_tokenizer=encoder_tokenizer, encoder_max_length=encoder_max_length,
        min_qwen_tokens=min_qwen_tokens, strip_stable=strip_stable)
