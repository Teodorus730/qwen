"""Copy existing scientific inputs and freeze the new development protocol."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import shutil
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT / 'gp_demo_20261007/plot_packages'))
import numpy as np


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def read(p):
    return json.loads(p.read_text(encoding='utf-8'))


def write(p, value):
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')


protocol = dict(
    version='srs_map_shared_label_search_v1',
    created_utc=datetime.now(timezone.utc).isoformat(),
    status='development_protocol_before_new_fits_on_previously_opened_oracles',
    pools={}, seeds=list(range(100, 120)), epsilon=.05,
    initial_per_domain=32, next_per_domain=10, initial_budget=192, total_budget=252,
    primary_pool='task_B', secondary_pool='confirmation_A',
    primary='macro next-batch recall of the true top10 within the common remaining68/domain; GP minus exact random expectation10/68',
    decision='conditional bootstrap lower bound >0 is positive development evidence on this pool; no automatic production promotion',
    random_next_seed_offset=202610080,
    bootstrap_seed=20261008, bootstrap_repetitions=10000,
    gp='same global BGE CLS L2 Matérn3/2 as frozen product; raw target; normalized y; marginal-likelihood optimization; zero restarts',
    baselines={
        'random':'10 uniform samples without replacement per domain from common remaining68',
        'krr':'existing9 alpha/gamma candidates, 3-fold MAE CV within initial192 only',
        'bayesian_ridge':'StandardScaler + sklearn BayesianRidge defaults',
        'cluster_mean':'fixed4 BGE KMeans clusters/domain, n_init10, seed; observed mean within cluster; empty cluster->domain mean',
        'domain_mean':'mean observed JSD per domain; constant score ties resolved by sampleID'},
    theta='hybrid uses initialSRS32/domain only; random comparator can also use SRS42/domain after252',
    costs='record virtual document budget, actual Qwen token positions, local CPU fit/predict/select; cached BGE/oracle preparation excluded from CPU timings',
    secondary=['paired actual random draw', 'full-pool top10 recall after252',
               'mean true JSD of next60', 'common remaining408 MAE/R2 before acquisition',
               'per-domain results', 'GP vs KRR/BayesRidge/cluster mean',
               'theta error initial192 vs random252', 'token counts and CPU seconds'],
    limitations=[
        'Both oracles were already opened before proposing this hypothesis: development, not untouched confirmation.',
        '20 seeds are conditional repeated selection plans on each fixed pool; no generalization guarantee.',
        'Primary uses exact random expectation; secondary contrasts are descriptive and unadjusted.',
        'One additional batch, no re-fitting on acquired labels, no kernel/feature/acquisition sweeps.',
        'No student training; high JSD is not demonstrated learning utility.',
        'Equal252 documents need not mean equal token/GPU compute.',
        'BGE preparation and original Qwen oracle measurements are reused, not newly timed.'])

for number, (name, original) in enumerate([
    ('task_B', 'gp_task_confirmation_20261007'),
    ('confirmation_A', 'confirmation_aligned_20261007')]):
    source = ROOT / original / 'engine/results/data_sealed'
    destination = HERE / 'inputs' / name
    destination.mkdir(parents=True, exist_ok=True)
    setup = read(source / 'setup.json')
    seal = read(source / 'oracle_seal.json')
    assert sha(source / 'oracle.npz') == seal['oracle_sha256']
    assert sha(source / 'features.npz') == setup['file_sha256']['features.npz']
    for filename in ['features.npz', 'oracle.npz']:
        shutil.copyfile(source / filename, destination / filename)
    with np.load(source / 'oracle.npz') as a:
        domains, ids = a['domains'], a['ids']
    rows = [json.loads(line) for line in (source / 'pool.jsonl').read_text(encoding='utf-8').splitlines()]
    assert [r['sample_id'] for r in rows] == ids.tolist()
    counts = np.array([len(r['alignment']['aligned_input_ids']) for r in rows])
    np.save(destination / 'token_counts.npy', counts)
    original_plans = read(source / 'plans.json')
    plans = {}
    for seed in protocol['seeds']:
        initial = np.array(original_plans[str(seed)]['srs'], dtype=int)
        remaining = np.setdiff1d(np.arange(len(ids)), initial)
        rng = np.random.default_rng(protocol['random_next_seed_offset'] + 1000 * number + seed)
        chosen = np.concatenate([rng.choice(remaining[domains[remaining] == d], 10, replace=False)
                                 for d in sorted(set(domains))])
        plans[str(seed)] = dict(initial=initial.tolist(), random_next=chosen.tolist())
    write(destination / 'plans.json', plans)
    protocol['pools'][name] = dict(
        original_directory=original, domains=sorted(set(domains)), size=len(ids),
        original_setup_sha256=sha(source / 'setup.json'),
        original_study_sha256=sha(source / 'study.json'),
        sha256={filename: sha(destination / filename) for filename in
                ['features.npz', 'oracle.npz', 'plans.json', 'token_counts.npy']})

protocol['experiment_sha256_before_run'] = sha(HERE / 'experiment.py')
write(HERE / 'protocol.json', protocol)
print(json.dumps({'status':'protocol_saved_before_new_fits', 'pools':list(protocol['pools']),
                  'seeds':len(protocol['seeds']), 'new_qwen_measurements':0,
                  'protocol_sha256':sha(HERE/'protocol.json')}, ensure_ascii=False))
