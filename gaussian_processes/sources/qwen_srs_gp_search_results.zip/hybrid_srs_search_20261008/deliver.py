"""Readable report, figures and a notebook that recomputes the experiment."""
from pathlib import Path
import ast
import json
import sys
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT / 'gp_demo_20261007/plot_packages'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

summary = json.loads((HERE / 'results/summary.json').read_text(encoding='utf-8'))
pools = summary['pools']
labels = {'gp':'GP', 'krr':'KRR', 'bayesian_ridge':'Bayesian Ridge',
          'cluster_mean':'Cluster mean', 'random':'Random'}
methods = list(labels)


def number(value, digits=2):
    return f'{value:.{digits}f}'.replace('.', ',')


def percent(value):
    return number(100 * value)


def interval(value, multiplier=100):
    return '[' + '; '.join(number(multiplier * x) for x in value['conditional_95']) + ']'


plot_dir = HERE / 'plots'
plot_dir.mkdir(exist_ok=True)
fig, axes = plt.subplots(1, 2, figsize=(12, 4.7), sharey=True)
for ax, name in zip(axes, ['task_B', 'confirmation_A']):
    p = pools[name]
    values = [100 * p['methods'][m]['next_top10_recall'] for m in methods]
    ax.bar(range(len(methods)), values, color=['#386cb0','#2ca58d','#85b369','#c0a568','#a6a6a6'])
    ax.axhline(100 * p['exact_random_expected_recall'], color='#444444', ls='--',
               label='Exact random expectation: 14.71%')
    ax.set_xticks(range(len(methods)), [labels[m] for m in methods], rotation=25, ha='right')
    ax.set_title(name + ' (opened development pool)')
    ax.set_ylim(0, 35)
    ax.grid(axis='y', alpha=.2)
    for x, value in enumerate(values):
        ax.text(x, value + .7, f'{value:.1f}', ha='center', fontsize=10)
axes[0].set_ylabel('Recall of remaining top-10 (%)')
axes[1].legend(loc='upper right', fontsize=8)
fig.suptitle('Same initial 192 labels; next 10 candidates in each domain')
fig.tight_layout()
fig.savefig(plot_dir / 'search_recall.png', dpi=180)
plt.close(fig)

fig, axes = plt.subplots(1, 2, figsize=(10, 4.5), sharey=True)
for ax, name in zip(axes, ['task_B', 'confirmation_A']):
    p = pools[name]
    values = [p['theta_initial192_error_pp'], p['theta_random252_error_pp']]
    ax.bar([0, 1], values, color=['#386cb0','#a6a6a6'])
    ax.set_xticks([0, 1], ['Hybrid: map uses 192', 'Random: map uses 252'])
    ax.set_title(name)
    ax.grid(axis='y', alpha=.2)
    for x, value in enumerate(values):
        ax.text(x, value + .06, f'{value:.2f}', ha='center')
axes[0].set_ylabel('Mean absolute domain theta error (percentage points)')
fig.suptitle('Search uses the extra 60 labels; targeted labels cannot be pooled into SRS theta')
fig.tight_layout()
fig.savefig(plot_dir / 'theta_tradeoff.png', dpi=180)
plt.close(fig)

parts = [
    '# Случайная карта и адресный поиск: эксперимент 8 октября 2026 года\n',
    '**Гибридная схема дала положительный результат для поиска на двух сохранённых пулах. '
    'Но необходимость именно GP не подтверждена: KRR нашёл почти столько же сильных расхождений.** '
    'При том же общем бюджете случайный добор лучше уточнял карту θ.\n',
    'Это новый расчёт моделей на реальных сохранённых измерениях Qwen. Оба пула уже были открыты: '
    'опыт является development-контролем, а не проверкой на новых untouched данных. '
    f'Выполнено 20 планов отбора на каждом из двух пулов. CPU-запуск завершился с exit code 0 за '
    f'{number(summary["seconds"], 1)} секунды; новых запусков Qwen и обучения ученика не было.\n',
    '## Какой вопрос проверяли\n',
    'Можно ли сначала измерить случайную выборку, использовать её для карты доменов, '
    'а на тех же метках обучить общий GP и искать им ещё не измеренные большие расхождения? '
    'И даёт ли GP больше, чем более простые модели на тех же признаках?\n',
    'JSD — разница между распределениями следующего токена учителя Qwen3.5-2B-Base '
    'и ученика Qwen3.5-0.8B-Base, усреднённая по согласованному raw prefix. '
    'θ — доля текстов домена с JSD ≤ 0,05. Большой JSD здесь не равен ошибочному ответу '
    'или доказанной полезности текста для обучения.\n',
    '## Данные и алгоритм\n',
    'В каждом пуле 600 текстов MMLU: шесть доменов по 100 текстов. Использованы прежние '
    'BGE-base-en-v1.5 CLS L2 признаки, полный vocabulary JSD и согласованные префиксы с лимитом 256. '
    'Настройки GP оставлены прежними: один глобальный Matérn-3/2, raw JSD, нормализация цели, '
    'подбор параметров kernel по marginal likelihood без restarts. Новых sweeps нет.\n',
    'Пул B — task-confirmation от 7 октября. Пул A — первое confirmation от 7 октября. '
    'В этой новой проверке оба считаются development. Использованы сохранённые SRS-планы seeds 100–119.\n',
    '```text\nдля каждого пула и seed:\n'
    '    initial = 32 случайных текста каждого домена, всего 192\n'
    '    remaining = остальные 68 текстов каждого домена, всего 408\n'
    '    theta = доля JSD ≤ 0,05 среди initial соответствующего домена\n\n'
    '    обучить GP, KRR и Bayesian Ridge только на 192 initial метках\n'
    '    построить кластерную оценку только по наблюдённым меткам\n'
    '    для каждого предиктора выбрать 10 максимальных прогнозов в каждом домене\n'
    '    для random выбрать 10 случайных текстов из того же remaining\n'
    '    сохранить прогнозы и выбранные позиции\n\n'
    '    по полному сохранённому oracle оценить качество каждого добора\n'
    '    сравнить по 60 новых текстов: общий виртуальный бюджет 252 на метод\n'
    '    отдельно пересчитать theta random по его 42 случайным текстам на домен\n'
    '```\n',
    'Все предикторы видели одинаковые метки. Полный oracle не передавался в функцию обучения '
    'и выбора кандидатов. Прогнозы и выбранные позиции сохранены до вызова функции оценки. '
    'После добора модели не переобучались: проверялся один следующий пакет.\n',
    'KRR — kernel ridge regression на BGE: прежние девять комбинаций alpha/gamma, '
    'подбор только внутри 192 начальных меток через трёхчастную CV. Bayesian Ridge — '
    'линейная регрессия с автоматической регуляризацией. Кластерная оценка — четыре '
    'KMeans-кластера внутри каждого домена и средний наблюдённый JSD кластера; '
    'для кластера без меток используется среднее домена. Это конкретная простая реализация, '
    'а не проверка всех вариантов кластеризации. Одинаковые прогнозы разрешаются по sample ID.\n',
    '## Основной результат: поиск следующих текстов\n',
    'Для каждого домена сначала определяется истинная десятка самых больших JSD '
    '**среди оставшихся 68 текстов**. Затем считаем, сколько из неё попало в предложенные '
    '10 кандидатов. Это Recall@10: больше — лучше. Случайное ожидание точно равно '
    '10/68 = 14,71%. Оно отличается от случайного полного top-10 всего домена.\n',
    '| Метод добора | Пул B, recall | Пул A, recall |\n|---|---:|---:|'
]
for m in methods:
    parts.append(f'| {labels[m]} | {percent(pools["task_B"]["methods"][m]["next_top10_recall"])}% | '
                 f'{percent(pools["confirmation_A"]["methods"][m]["next_top10_recall"])}% |')
parts.append('| Точное случайное ожидание | 14,71% | 14,71% |\n')
parts.append('![Поиск следующих расхождений](plots/search_recall.png)\n')
parts.append('| Парная разность recall, п.п. | Пул B: средняя; условный 95% интервал | '
             'Пул A: средняя; условный 95% интервал |\n|---|---:|---:|')
for key, title in [('gp_minus_random_expectation','GP − случайное ожидание'),
                   ('gp_minus_random_draw','GP − фактический random'),
                   ('gp_minus_krr','GP − KRR'),
                   ('gp_minus_bayesian_ridge','GP − Bayesian Ridge'),
                   ('gp_minus_cluster_mean','GP − кластерная оценка')]:
    a, b = [pools[n]['comparisons'][key] for n in ['task_B','confirmation_A']]
    parts.append(f'| {title} | {percent(a["mean"])}; {interval(a)} | {percent(b["mean"])}; {interval(b)} |')
parts += ['\nGP превысил точное случайное ожидание во всех 20 планах каждого пула. '
          'Его преимущество над KRR не установлено: интервалы разницы включают ноль. '
          'Все интервалы условны на соответствующий фиксированный пул; 20 seeds не заменяют '
          '20 независимых корпусов. Дополнительные сравнения описательные, без поправки '
          'на множественные проверки.\n',
          '## Что получается после полного бюджета 252\n',
          'Здесь считаем другую десятку: истинный top-10 **всех 100 текстов домена**. '
          'Проверяем, сколько из неё найдено объединением начальных 32 и дополнительных 10 измерений.\n',
          '| Метод | Пул B: найденный full-pool top-10 | Пул A: найденный full-pool top-10 |\n|---|---:|---:|']
for m in methods:
    parts.append(f'| {labels[m]} | {percent(pools["task_B"]["methods"][m]["full_top10_recall_after_252"])}% | '
                 f'{percent(pools["confirmation_A"]["methods"][m]["full_top10_recall_after_252"])}% |')
parts += ['\n## Цена поиска для карты θ\n',
          'До добора карта у всех веток одинаковая: это одна и та же случайная выборка 192 текстов. '
          'Её равенство не является экспериментальной победой гибрида. '
          'После добора random имеет законную случайную выборку 42 текста на домен и может уточнить θ. '
          'Предикторы добирают экстремумы; просто включать их в прямую оценку θ нельзя.\n',
          '| Оценка карты | Пул B: ошибка θ, п.п. | Пул A: ошибка θ, п.п. |\n|---|---:|---:|',
          f'| Гибрид: карта по initial192 | {number(pools["task_B"]["theta_initial192_error_pp"])} | '
          f'{number(pools["confirmation_A"]["theta_initial192_error_pp"])} |',
          f'| Random: карта по всем252 | {number(pools["task_B"]["theta_random252_error_pp"])} | '
          f'{number(pools["confirmation_A"]["theta_random252_error_pp"])} |\n',
          '![Компромисс карты и поиска](plots/theta_tradeoff.png)\n',
          'Следовательно, гибрид выигрывает поиск, но не превосходит random по всем выходам. '
          'Дополнительный бюджет можно потратить на поиск или на уточнение карты.\n',
          '## Индивидуальный прогноз JSD и измеренные затраты\n',
          'Ошибка прогнозов посчитана до добора на одних и тех же оставшихся 408 текстах. '
          'Время ниже — локальные CPU fit/predict/select на одном потоке, при уже готовых BGE '
          'и метках Qwen. Оно не включает BGE, Qwen, I/O и отдельную подготовку медианного '
          'расстояния для GP. Это добавочные измеренные стадии, а не полная стоимость системы.\n',
          '| Предиктор | MAE JSD, B | MAE JSD, A | CPU fit+predict+select, B / A, с |\n|---|---:|---:|---:|']
for m in methods[:-1]:
    a, b = [pools[n]['methods'][m] for n in ['task_B','confirmation_A']]
    seconds = [sum(v[k] for k in ['fit_seconds','prediction_seconds','selection_seconds']) for v in [a,b]]
    parts.append(f'| {labels[m]} | {number(a["unselected_mae"],6)} | {number(b["unselected_mae"],6)} | '
                 f'{number(seconds[0],3)} / {number(seconds[1],3)} |')
parts += ['\nKRR почти совпал с GP в поиске и индивидуальной ошибке, при меньшем времени '
          'измеренных CPU-стадий. Bayesian Ridge также дал близкий поисковый результат. '
          'Из этого нельзя вычислить экономию всего GPU-пайплайна: всем этим предикторам '
          'нужны BGE, а random обходится без энкодера.\n']
for name in ['task_B','confirmation_A']:
    p = pools[name]
    gp, random = p['methods']['gp'], p['methods']['random']
    parts.append(f'В {name} дополнительные60 текстов GP содержали в среднем '
                 f'{number(gp["new_token_positions"],0)} Qwen-позиций против '
                 f'{number(random["new_token_positions"],0)} у random '
                 f'(+{number(100*(gp["new_token_positions"]/random["new_token_positions"]-1))}%). '
                 'Равные количества документов поэтому не равны строго одинаковым вычислениям.\n')
parts += ['## Результаты по доменам\n',
          'Ни один домен не исключён после просмотра результатов. Положительный общий эффект '
          'не означает выигрыш в каждом домене. R² индивидуального прогноза и recall поиска '
          'отвечают на разные вопросы.\n',
          '| Пул | Домен | GP recall | KRR recall | GP R² внутри домена |\n|---|---|---:|---:|---:|']
for name in ['task_B','confirmation_A']:
    p = pools[name]
    for d, v in p['methods']['gp']['by_domain'].items():
        k = p['methods']['krr']['by_domain'][d]
        parts.append(f'| {name} | {d} | {percent(v["remaining_top10_recall"])}% | '
                     f'{percent(k["remaining_top10_recall"])}% | {number(v["unselected_r2"],3)} |')
parts += ['\nВ частности, moral_scenarios на B дал GP recall 13,5% при случайном ожидании 14,71%. '
          'Гибрид не является правилом «GP хорош везде». Выбирать удачные домены по этой таблице '
          'можно лишь как новую разработку с отдельной последующей проверкой.\n',
          '## Вывод и границы\n',
          '1. Схема «случайная карта + предиктор для поиска» технически работает и улучшила поиск '
          'на обоих имеющихся пулах при одинаковом бюджете документов.\n'
          '2. Именно GP для этого не обязателен: преимущество над KRR не установлено.\n'
          '3. Если нужен только точный θ, дополнительные случайные измерения полезнее, '
          'чем выделение того же бюджета на экстремумы.\n'
          '4. Это replay на открытых пулах, не новый untouched confirmation, не natural-text перенос '
          'и не доказательство пользы выбранных текстов для обучения.\n'
          '5. Полная окупаемость по GPU-ресурсам не установлена. Измерены добавочные CPU-стадии '
          'и число токенных позиций; BGE/Qwen здесь переиспользованы.\n',
          'Для применения разумно сохранить адресный поиск как отдельную функцию. '
          'Сначала выбирать между GP и простым предиктором; подтверждение на новых данных '
          'потребуется перед заявлением о переносимости. Возвращать GP как обязательный '
          'оцениватель всей карты эти результаты не требуют.\n',
          '## Файлы и воспроизведение\n',
          '- [Протокол до новых fits](protocol.json).\n'
          '- [Код эксперимента](experiment.py).\n'
          '- [Общий результат и версии среды](results/summary.json).\n'
          '- [Все планы и метрики B](results/task_B/seed_results.json).\n'
          '- [Все планы и метрики A](results/confirmation_A/seed_results.json).\n'
          '- [Независимый аудит](independent_audit.json): 40 наборов сохранённых прогнозов, '
          '240 результатов методов; пересчёт recall, θ, токенов и ошибок совпал.\n',
          'Для Colab: загрузить notebook `qwen_srs_gp_search_benchmark.ipynb`, выполнить setup '
          'и загрузить `qwen_srs_gp_search_inputs.zip`. GPU не нужен. Notebook заново обучает '
          'модели и считает результаты; в его кодовых ячейках готовые выводы не подставлены.\n']
(HERE / 'РЕЗУЛЬТАТЫ.md').write_text('\n'.join(parts), encoding='utf-8')

input_zip = ROOT / 'qwen_srs_gp_search_inputs.zip'
with zipfile.ZipFile(input_zip, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in [HERE/'protocol.json', HERE/'experiment.py', *sorted((HERE/'inputs').rglob('*'))]:
        if p.is_file():
            z.write(p, p.relative_to(HERE).as_posix())

# Native, readable code cells, taken verbatim from the executed functions.
source = (HERE / 'experiment.py').read_text(encoding='utf-8')
lines = source.splitlines(keepends=True)
tree = ast.parse(source)
functions = {n.name: ''.join(lines[n.lineno-1:n.end_lineno]) for n in tree.body
             if isinstance(n, ast.FunctionDef)}
cells = []


def cell(kind, content):
    result = dict(cell_type=kind, metadata={}, source=content.splitlines(keepends=True))
    if kind == 'code':
        result.update(execution_count=None, outputs=[])
    cells.append(result)


cell('markdown', '# Случайная карта + адресный поиск\n\n'
     'Проверка гипотезы на двух сохранённых 600-текстовых пулах. Здесь реальные JSD уже измерены '
     'раньше, но GP и контрольные модели обучаются заново. Оба пула development. '
     'GPU не требуется.\n\n'
     'Для каждого seed: SRS192 → карта θ; те же метки → общий предиктор → '
     'следующие60 кандидатов. Контроль добирает60 случайно. Сравниваем поиск и карту '
     'при общем бюджете252, а также GP с KRR, Bayesian Ridge и простой кластерной оценкой.')
cell('code', '%pip -q install numpy==2.1.3 scipy==1.16.3 scikit-learn==1.6.1 threadpoolctl==3.7.0 matplotlib==3.11.2\n')
cell('markdown', '## Загрузить данные\n\nВыбери `qwen_srs_gp_search_inputs.zip`. '
     'Архив содержит сохранённые признаки, JSD и планы, а не готовые результаты нового опыта.')
cell('code', 'from pathlib import Path\nimport zipfile\nfrom google.colab import files\n\n'
     'WORK = Path("/content/gp_srs_search")\nWORK.mkdir(exist_ok=True)\n'
     'uploaded = files.upload()\ninput_zip = next(iter(uploaded))\n'
     'with zipfile.ZipFile(input_zip) as archive:\n    archive.extractall(WORK)\n')
imports = ''.join(''.join(lines[n.lineno-1:n.end_lineno]) for n in tree.body
                  if isinstance(n, (ast.Import, ast.ImportFrom)))
cell('code', imports + '\nHERE = WORK\nPREDICTORS = ' + repr(['gp','krr','bayesian_ridge','cluster_mean','domain_mean']) + '\n')
for title, names in [
    ('Файлы и порядок кандидатов', ['read_json','write_json','file_sha','top_indices']),
    ('Обучение только на initial192 и выбор кандидатов', ['fit_and_select']),
    ('Оценка после сохранения выбора', ['theta_estimate','theta_error','score_choices']),
    ('Условные интервалы и сводка', ['paired_interval','aggregate_pool']),
    ('Запуск всех 40 планов', ['run_experiment'])]:
    cell('markdown', '## ' + title)
    cell('code', '\n\n'.join(functions[n] for n in names) + '\n')
cell('code', 'report = run_experiment(WORK)\n')
cell('markdown', '## Результат\n\nRecall — доля найденной истинной десятки среди оставшихся68 '
     'текстов домена. θ-error — ошибка карты в процентных пунктах. Все интервалы условны '
     'на открытый пул; вторичные сравнения описательные.')
cell('code', 'for pool, result in report["pools"].items():\n'
     '    print("\\n", pool, result["decision"])\n'
     '    for method, metrics in result["methods"].items():\n'
     '        print(f"{method:16s} next recall={100*metrics[\"next_top10_recall\"]:.2f}%")\n'
     '    print("theta-error hybrid192:", result["theta_initial192_error_pp"])\n'
     '    print("theta-error random252:", result["theta_random252_error_pp"])\n'
     '    print("GP minus KRR:", result["comparisons"]["gp_minus_krr"])\n')
cell('code', 'import shutil\nresult_zip = shutil.make_archive("/content/qwen_srs_gp_search_results", "zip", WORK / "results")\n'
     'files.download(result_zip)\n')
notebook = dict(nbformat=4, nbformat_minor=5, cells=cells,
                metadata={'kernelspec':{'display_name':'Python 3','language':'python','name':'python3'},
                          'language_info':{'name':'python'}})
notebook_path = ROOT / 'qwen_srs_gp_search_benchmark.ipynb'
notebook_path.write_text(json.dumps(notebook, ensure_ascii=False, indent=1), encoding='utf-8')
for c in cells:
    text = ''.join(c['source'])
    if c['cell_type'] == 'code' and not text.startswith('%pip'):
        compile(text, str(notebook_path), 'exec')

result_zip = ROOT / 'qwen_srs_gp_search_results.zip'
with zipfile.ZipFile(result_zip, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in sorted(HERE.rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts:
            z.write(p, p.relative_to(ROOT).as_posix())
    z.write(notebook_path, notebook_path.name)
print(json.dumps({'report':str(HERE/'РЕЗУЛЬТАТЫ.md'), 'notebook':str(notebook_path),
                  'inputs_bytes':input_zip.stat().st_size,
                  'results_bytes':result_zip.stat().st_size,
                  'notebook_code_cells_compile':'passed'}, ensure_ascii=False))
