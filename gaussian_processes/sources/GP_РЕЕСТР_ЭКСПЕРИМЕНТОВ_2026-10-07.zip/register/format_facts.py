from pathlib import Path
import re

p = Path(__file__).resolve().parent / 'summary_facts.md'
t = p.read_text(encoding='utf-8')
t = re.sub(r'(?<=[а-яА-ЯёЁ])(?=[A-Za-z])|(?<=[A-Za-z])(?=[а-яА-ЯёЁ])', ' ', t)
t = re.sub(r'(?<=[0-9%])(?=[а-яА-ЯёЁ])|(?<=[а-яА-ЯёЁ])(?=[0-9])', ' ', t)
t = re.sub(r'(?<=\d)(?=(?:labels|seeds|pairedseeds|fits|states|random|train|val|test|components|предметов|случаев)\b)', ' ', t)
t = re.sub(r'(?<=[A-Za-z])(?=(?:MAE|R²|Recall|Spearman)\b)', ' ', t)
t = re.sub(r'(MAE|R²|Spearman|Recall|batch|scale|κ|ε)(?=\d)', r'\1 ', t)
t = re.sub(r'(?<=[;:])(?=\S)', ' ', t)
t = re.sub(r'(?<=[,])(?=[а-яА-ЯёЁA-Za-z])', ' ', t)
replacements = {
    '2 пула×': '2 пула ×', '4 пула×': '4 пула ×', '×5 seeds': '× 5 seeds',
    '×10 seeds': '× 10 seeds', '×20 перестановок': '× 20 перестановок',
    'полнаяобласть': 'полная область', 'последнийслой': 'последний слой',
    'моделейневыполнено': 'моделей не выполнено',
    'внутридоменныйR²': 'внутридоменный R²', 'logits/JSD': 'logits/JSD',
    'inferencecalls': 'inference calls', 'pairedseeds': 'paired seeds',
    'subjectmean': 'subject mean', 'DomainSpearman': 'Domain Spearman',
    'top10 overlap': 'top-10 overlap', 'groupedCV': 'grouped CV',
    'scaledtarget': 'scaled target', 'fit-time': 'fit time',
}
for old, new in replacements.items():
    t = t.replace(old, new)
p.write_text(t, encoding='utf-8')
