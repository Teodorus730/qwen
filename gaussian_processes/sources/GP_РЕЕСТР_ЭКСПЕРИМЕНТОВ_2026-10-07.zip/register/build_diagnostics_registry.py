from pathlib import Path
from collections import defaultdict
import hashlib
import json
import math
import statistics
import sys

sys.stdout.reconfigure(encoding='utf-8')
ROOT = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
FILES = [
    ('learning_and_features.json', 'Кривые бюджета и дополнительные статистики текста'),
    ('map_acquisition.json', 'Сбалансированный random и отбор около порога'),
    ('optimizer_restarts.json', 'Дополнительные старты оптимизации RBF'),
    ('search_vs_map.json', 'Random/UCB: качество прогноза и карты'),
    ('within_domain_permutations.json', 'Перемешивание JSD внутри предметов'),
    ('nearest_neighbor_diagnostic.json', 'Расхождения ближайших соседей против случайных пар'),
    ('feature_associations.json', 'Связь статистик текста с внутридоменной JSD'),
    ('finite_holdout_reference.json', 'Доля полного пула против доли малого test: описательная проверка'),
    ('large_targets.json', 'Большие конечные синтетические targets: сохранённая диагностика'),
]
METRICS = {'mae', 'r2', 'macro_r2', 'theta_error', 'macro_theta_error', 'rmse', 'top10_recall',
           'std_mu', 'std_y', 'sigma_mean', 'sigma_std', 'train_mae', 'domain_baseline_mae',
           'nearest_pair_mse', 'random_pair_expected_mse', 'nearest_vs_random_ratio',
           'within_domain_spearman', 'length_spearman', 'extrapolation_relative_mae'}
AXES = ['pool', 'model', 'budget', 'policy', 'restarts', 'scale', 'transform', 'domain', 'feature']
SEED_AXES = ['seed', 'repetition']

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


sources = []
experiments = []
for filename, title in FILES:
    path = ROOT / 'limits_diagnostics' / filename
    data = read(path)
    rows = data if isinstance(data, list) else data.get('rows') if isinstance(data, dict) else None
    metadata = {k: v for k, v in data.items() if k != 'rows'} if isinstance(data, dict) else {}
    axes = {}
    groups = defaultdict(list)
    if rows is not None:
        for name in AXES + SEED_AXES:
            values = {r[name] for r in rows if isinstance(r, dict) and name in r and isinstance(r[name], (str, int, float))}
            if values:
                axes[name] = sorted(values, key=lambda v: (type(v).__name__, v))
        for row in rows:
            group = tuple((name, row[name]) for name in AXES if name in row)
            groups[group].append(row)
        aggregate = []
        for group, group_rows in groups.items():
            entry = dict(group)
            entry['n_records'] = len(group_rows)
            for metric in sorted(METRICS):
                values = [r[metric] for r in group_rows if isinstance(r.get(metric), (int, float)) and not isinstance(r[metric], bool) and math.isfinite(r[metric])]
                if values:
                    entry[metric + '_mean'] = statistics.mean(values)
            aggregate.append(entry)
    else:
        aggregate = []
    experiments.append({'id': 'diagnostic_' + path.stem, 'title': title,
                        'status': 'saved_completed_records', 'source': str(path),
                        'completed_record_count': len(rows) if rows is not None else None,
                        'count_unit': 'saved diagnostic row; not automatically an independent dataset or GP fit',
                        'axes': axes, 'source_metadata': metadata, 'aggregate': aggregate,
                        'per_run_rows': rows})
    sources.append({'path': str(path), 'role': 'primary_diagnostic', 'row_count': len(rows) if rows is not None else None,
                    'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})

for filename in ['provenance.json', 'scope.json', 'summary.json']:
    path = ROOT / 'limits_diagnostics' / filename
    sources.append({'path': str(path), 'role': 'scope_or_aggregate', 'row_count': None,
                    'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
verification_paths = [
    'previous_run_diagnosis.json',
    'received_run_analysis/verified_summary.json',
    'received_run_analysis/domain_baseline_check.json',
    'antigravity_review/audit.json',
    'antigravity_review/matched_summary.json',
    'product_results_review/audit.json',
    'product_results_review/summary.json',
    'benchmark_v1_review/audit.json',
    'user_fixed_review_20261006/audit.json',
    'antigravity_return_review_20261007/independent_numeric_review.json',
    'plain_product_fix/verification.json',
    'task2_product_tests/verification.json',
]
verification_index = []
for relative in verification_paths:
    path = ROOT / relative
    entry = {'path': str(path), 'role': 'audit_or_product_execution_not_new_scientific_comparison', 'row_count': None}
    if path.is_file():
        data = read(path)
        entry['sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
        verification_index.append({'source': str(path), 'top_level_type': type(data).__name__,
                                   'keys': list(data) if isinstance(data, dict) else None})
        sources.append(entry)
    else:
        verification_index.append({'source': str(path), 'status': 'missing_local_file'})

registry = {'schema_version': 1, 'generated_date': '2026-10-07',
            'scope': 'Saved diagnostics on opened early cached pools; audits indexed separately',
            'new_confirmation_data': False,
            'protocol_provenance': read(ROOT / 'limits_diagnostics/provenance.json'),
            'protocol_scope': read(ROOT / 'limits_diagnostics/scope.json'),
            'experiments': experiments, 'verification_index': verification_index, 'files': sources,
            'limitations': ['Saved rows are not counted as independent new datasets.',
                            'Synthetic large-target rows may overlap the early registry; do not sum them as new fits.',
                            'Audits verify existing outputs; they do not establish new comparative quality.']}
target = OUT / 'diagnostics_registry.json'
target.write_text(json.dumps(registry, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
print(json.dumps({'file': str(target), 'experiments': len(experiments), 'sources': len(sources),
                  'row_counts': {e['id']: e['completed_record_count'] for e in experiments}}, ensure_ascii=False))
