from pathlib import Path
import csv
import hashlib
import json
import sys
import zipfile

sys.stdout.reconfigure(encoding='utf-8')

ROOT = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
PARTS = ['early_registry.json', 'diagnostics_registry.json', 'benchmark_registry.json', 'late_registry.json']


def digest(data):
    return hashlib.sha256(data).hexdigest()


def compact(value):
    if isinstance(value, str):
        return value
    return json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)


def discover_source_entries(value):
    if isinstance(value, dict):
        for key, child in value.items():
            if key in ('files', 'source_files', 'sources', 'source_paths'):
                if isinstance(child, list):
                    for entry in child:
                        if isinstance(entry, str):
                            yield {'path': entry}
                        elif isinstance(entry, dict) and any(k in entry for k in ('path', 'file', 'source')):
                            yield entry
                elif isinstance(child, str):
                    yield {'path': child}
            yield from discover_source_entries(child)
    elif isinstance(value, list):
        for child in value:
            yield from discover_source_entries(child)


phases = []
for name in PARTS:
    path = OUT / name
    phases.append({'registry': name, 'data': json.loads(path.read_text(encoding='utf-8-sig'))})

register = {'date': '2026-10-07', 'scope': 'Executed scientific series documented in three source registries',
            'count_semantics': 'Metric rows, trajectories, GP fits, saved states and physical measurements are distinct counts.',
            'phases': phases}
(OUT / 'all_experiments.json').write_text(json.dumps(register, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')

lines = [
    '# Реестр выполненных экспериментов GP — 2026-10-07',
    '',
    'Источник каждого числа указан в записях ниже. Здесь перечислены выполненные серии. Планируемые гипотезы не являются результатами.',
    '',
    'Строка метрик, траектория отбора, обучение GP, сохранённое состояние и физическое измерение Qwen — разные единицы. Количества не суммируются как независимые эксперименты.',
    '',
    'JSD: расхождение распределений следующего токена, усреднённое по позициям текста. θ: доля JSD≤0,05. MAE: средняя абсолютная ошибка JSD. θ-error: средняя абсолютная ошибка доменных долей в процентных пунктах. Ни одна из них не является accuracy ответов Qwen.',
    '',
    '| Сравнение | Измеренный результат |',
    '|---|---|',
    '| GP против SRS, новый пул №1, точная θ | 4,893 против 4,557 п.п.; убедительного выигрыша GP нет |',
    '| GP против SRS, новый пул №2, порядок предметов | Spearman 0,9714 против 0,9434; положительный условный результат на этом пуле |',
    '| GP против среднего JSD по SRS-меткам, новый пул №2 | MAE 0,008676 против 0,009634; примерно 9,94% ниже |',
    '| GP против SRS, новый пул №2, точная θ | 3,993 против 4,096 п.п.; убедительного выигрыша нет |',
    '| Измеренный top-10, новый пул №2 | Recall 23,25% у GP-ветки против 30,67% SRS |',
    '| GP+random против GP+σ, открытый finite pool | θ-error 5,805605 против 7,278262 п.п.; random лучше по θ |',
    '',
    '20 seeds одного пула характеризуют случайный отбор на нём, не 20 независимых корпусов. Ранние top-30 и Qwen-feature результаты не являются прямым сравнением с поздними full-JSD и независимыми признаками.',
    '',
    '| Раздел | Записей серий и контролей | Полные результаты |',
    '|---|---:|---|',
    '| Ранние серии | 7 | early_registry.json |',
    '| Дополнительная диагностика | 9 | diagnostics_registry.json |',
    '| 1–3 октября | 27 | benchmark_registry.json |',
    '| 5–7 октября | 12 | late_registry.json |',
    '',
    '55 записей реестра включают научные серии, диагностику и технические контроли. Это не 55 независимых датасетов. Все per-run строки сохранены в JSON-приложениях; основной текст не дублирует массивы прогнозов.',
    '',
]

for phase in phases:
    data = phase['data']
    lines += [f"**Первичный реестр: {phase['registry']}**", '']
    for key, value in data.items():
        if key in ('experiments', 'files', 'records', 'rows', 'extracted_rows', 'raw_records'):
            continue
        if isinstance(value, (dict, list)):
            lines += [f'`{key}`:', '', '```json', compact(value), '```', '']
        else:
            lines += [f'- `{key}`: {compact(value)}', '']
    exps = data.get('experiments', [])
    if isinstance(exps, dict):
        exps = [dict(value, id=key) if isinstance(value, dict) else {'id': key, 'value': value} for key, value in exps.items()]
    for number, exp in enumerate(exps, 1):
        title = exp.get('title') or exp.get('name') or exp.get('id') or f'Series {number}'
        lines += [f'**{number}. {title}**', '']
        for key, value in exp.items():
            if key in ('title', 'name', 'records', 'rows', 'extracted_rows', 'raw_records', 'predictions',
                       'case_records', 'live_case_record', 'configuration_plan', 'configuration_plan_by_pool',
                       'span_reports', 'regressions') or key.endswith('_rows'):
                if isinstance(value, list):
                    lines += [f'- `{key}`: {len(value)} полных записей в исходном JSON-реестре.', '']
                continue
            if isinstance(value, (dict, list)):
                lines += [f'`{key}`:', '', '```json', compact(value), '```', '']
            else:
                lines += [f'- `{key}`: {compact(value)}', '']
    lines += ['Подробные записи и ссылки: `' + phase['registry'] + '`.', '']

report = ROOT / 'ТЕХНИЧЕСКИЕ_ЗАПИСИ_GP_2026-10-07.md'
report.write_text('\n'.join(lines) + '\n', encoding='utf-8')
main_report = ROOT / 'РЕЕСТР_ЭКСПЕРИМЕНТОВ_GP_2026-10-07.md'
main_report.write_text((OUT / 'summary_facts.md').read_text(encoding='utf-8'), encoding='utf-8')

manifest = []
payloads = {}
seen = set()
for phase in phases:
    for entry in discover_source_entries(phase['data']):
        raw = entry.get('path') or entry.get('file') or entry.get('source')
        if not isinstance(raw, str):
            continue
        member = entry.get('member') or entry.get('zip_member') or entry.get('archive_member')
        pointer = None
        if ' :: ' in raw:
            raw, member = raw.split(' :: ', 1)
        if '#' in raw:
            raw, pointer = raw.split('#', 1)
        path = Path(raw.replace('\\', '/'))
        if not path.is_absolute():
            path = ROOT / path
        key = (str(path), member)
        if key in seen:
            continue
        seen.add(key)
        record = {'source': str(path), 'member': member, 'pointer': pointer, 'reference': entry}
        try:
            if member:
                with zipfile.ZipFile(path) as zf:
                    content = zf.read(member)
                name = 'sources/' + path.name + '/' + str(member).replace('\\', '/')
            elif path.is_file() and path.suffix.lower() in ('.json', '.jsonl', '.csv', '.md', '.txt', '.py', '.zip') and path.stat().st_size <= 15_000_000:
                content = path.read_bytes()
                try:
                    relative = path.relative_to(ROOT).as_posix()
                except ValueError:
                    relative = path.name
                name = 'sources/' + relative
            else:
                record['packaging'] = 'Directory index; individual files are listed separately' if path.is_dir() else 'Referenced only: absent, non-text or large binary source'
                manifest.append(record)
                continue
            record.update(bytes=len(content), sha256=digest(content), packaged_as=name)
            payloads[name] = content
        except (OSError, KeyError, zipfile.BadZipFile) as exc:
            record['packaging'] = 'Referenced only'
            record['error'] = str(exc)
        manifest.append(record)

(OUT / 'source_manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
archive = ROOT / 'GP_РЕЕСТР_ЭКСПЕРИМЕНТОВ_2026-10-07.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
    zf.write(main_report, main_report.name)
    zf.write(report, report.name)
    for name in PARTS + ['all_experiments.json', 'source_manifest.json', 'compose_register.py',
                         'summary_facts.md', 'format_facts.py', 'build_diagnostics_registry.py']:
        zf.write(OUT / name, 'register/' + name)
    for name, content in sorted(payloads.items()):
        zf.writestr(name, content)
with zipfile.ZipFile(archive) as zf:
    assert zf.testzip() is None
    for name, content in payloads.items():
        assert zf.read(name) == content
receipt = {'report': str(main_report), 'report_bytes': main_report.stat().st_size, 'appendix': str(report),
           'appendix_bytes': report.stat().st_size, 'archive': str(archive),
           'archive_bytes': archive.stat().st_size, 'packaged_sources': len(payloads),
           'source_references': len(manifest), 'experiments_per_registry': {p['registry']: len(p['data'].get('experiments', [])) for p in phases}}
(OUT / 'receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(receipt, ensure_ascii=False))
