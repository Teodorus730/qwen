# Реестр экспериментов GP — 7 октября 2026

Область: выполненные серии и проверки, для которых сохранились результаты в проектной директории. Ссылки на исходные файлы, конфигурации и полные результаты каждого запуска находятся в приложениях. Запланированные, но не выполненные гипотезы результатами не считаются.

JSD — расхождение вероятностей следующего токена teacher/student, усреднённое по позициям текста. θ — доля текстов с JSD≤0,05. MAE — средняя абсолютная ошибка JSD. θ-error — средняя абсолютная ошибка доменных долей в процентных пунктах. Accuracy ответов Qwen не измерялась. Веса Qwen не обучались.

**1. Учёт выполненных серий**

В реестре 55 записей: 7 ранних серий, 9 дополнительных диагностик, 27 серий/контролей 1–3 октября, 12 серий/прогонов 5–7 октября. Это не 55 независимых датасетов. Сохранённая строка метрик, траектория отбора, GP fit, промежуточное состояние и измерение двух Qwen учитываются раздельно. Некоторые дополнительные расчёты переиспользуют те же данные.

| Серия | Условия | Фактически сохранено | Первичный реестр / ID |
|---|---|---: |---|
| Начальная исследовательская сетка | global/per-domain; raw/log; random/mean/σ/UCB; κ 1/2/5/10; ablations; 3 seeds | 105 строк: 35 конфигураций×3 | early / early_research_105 |
| Первые проверки из кеша | 4 предиктора; бюджеты 24/48/96; 10 seeds; отдельные стратегии поиска | 120 predictor +50 search | early / followup_170 |
| Второй MMLU-пул | Новые 6 предметов; прежние проверки | 90 predictor +30 search | early / fresh_validation_120 |
| Кластерный/случайный старт | 2 пула × 10 seeds×2 старта×2 стратегии; 120→192 | 80 траекторий | early / initial_design_control_80 |
| MiniLM/Qwen/BGE | Те же 2 пула; сравнения признаков и поиска | 280 predictor +120 search | early / representation_control_280_120 |
| Qwen-next | 2 пула; global/per-domain; RBF/Matérn; raw/log; κ; бюджеты | 300 завершённых траекторий; 350 бюджетных состояний | early / qwen_next_300 |
| Большие синтетические цели | 4 scale×raw/log | 8 строк; повторно представлены в diagnostics | early / positive_unbounded_target_8 |
| Бюджет и простые признаки | Два пула; 24/48/96/192/288/384; варианты признаков | 120 строк | diagnostics / diagnostic_learning_and_features |
| Отбор около порога | balanced random; threshold; balanced threshold | 30 строк | diagnostics / diagnostic_map_acquisition |
| Старты оптимизатора | RBF с 0/3 дополнительными restart | 20 строк | diagnostics / diagnostic_optimizer_restarts |
| Поиск против карты | random/UCB при одинаковой цене | 20 строк | diagnostics / diagnostic_search_vs_map |
| Перемешивание JSD внутри предметов | 2 пула ×3 splits×2 бюджета× 20 перестановок | 240 строк | diagnostics / diagnostic_within_domain_permutations |
| Ближайшие соседи | Внутридоменные пары | 12 строк | diagnostics / diagnostic_nearest_neighbor_diagnostic |
| Связь статистик текста с JSD | Два пула×6 статистик | 12 строк | diagnostics / diagnostic_feature_associations |
| Полная доля против малого test |20 test-текстов/предмет | Описательный расчёт; не GP fit | diagnostics / diagnostic_finite_holdout_reference |
| Основной predictor benchmark | 11 методов×4 пула × 5 seeds×96/192 | 440 результатов | benchmark / oct01_predictors |
| Acquisition benchmark | 4 политики×4 пула × 5 seeds; start24→96 | 80 траекторий | benchmark / oct01_acquisition |
| Token-Ridge/Token-GP | 2 метода×4 пула × 5 seeds×96/192 | 80 результатов | benchmark / oct01_token_predictors |
| PLS→GP | 4 пула × 5 seeds×96/192; train-CV2/4/8/16 компонент | 40 результатов | benchmark / oct01_projection |
| Full JSD/top-k | Одни 120 текстов; top30/100/256 и exact |120 документов; групповые результаты в JSON | benchmark / oct01_metric_exact_topk |
| LogJSD | Те же features/labels; 40 парных случаев +product | 41 log-fit | benchmark / oct02_log_target |
| Отбор/пакет в product | cluster-only; random; σbatch 1/4/12; random-start; 5 seeds | 30 случаев; 540 logged fits; 510 checked decisions | benchmark / oct02_product_acquisition_batch |
| Обрезка encoder по Qwen-prefix | Старые/исправленные признаки; те же labels | 40 fits | benchmark / oct02_prefix_crop |
| Более сильный encoder | 8 методов×4 пула × 5 seeds; 192 labels | 160 результатов | benchmark / oct03_strong_encoder |
| Encoder в старом product |3 представления× 5 seeds; cluster120→192 | 15 случаев; 105 fits | benchmark / oct03_encoder_product_transfer |
| Encoder на новом product-пуле |3 представления× 5 seeds; 600 новых текстов; общий кеш всех веток | 15 случаев; 575 новых парных измерений суммарно | benchmark / oct03_fresh_product_encoders |
| Признаки против выбранных labels |Фиксируем features или 192 IDs | 20 случаев | benchmark / oct03_encoder_selection_cross |
| MiniLM/BGE×σ/random |2 encoder×2 policy× 5 seeds; 120→192 |20 траекторий; 140 GP states | late / freeze_20261005_acquisition |
| Предикторы на одинаковых 192 IDs |2 encoder×6 методов× 5 seeds |60 результатов | late / freeze_20261005_predictors |
| Способы оценки θ |Прямая доля/GP CDF/Bayesian Ridge CDF; те же 192 train labels |Результаты по 5 seeds в JSON; повторно используемые fits | late / freeze_20261005_theta_estimators |
| Postfreeze MMLU |Новый 600-пул; 360/120/120; seed100; 120→192 |7 fits | late / postfreeze_20261005_mmlu |
| Postfreeze natural |Новый 600-пул; 520/40/40; seed100; 40→192 |14 fits | late / postfreeze_20261005_natural |
| Полный finite pool |Новые 600; 20 seeds; 192 labels/метод |20 итоговых GP fits | late / finite_pool_20261006 |
| Точное ожидание ошибки SRS |Тот же открытый finite pool; гипергеометрический расчёт |Новых GP fits и Qwen labels нет | late / finite_pool_exact_srs_posthoc_20261007 |
| Random/σ replay |Тот же открытый 600-пул; 20 seeds; общий start120→192 |260 fits | late / random_sigma_posthoc_20261007 |
| Fresh θ confirmation |Новый 600-пул; 20 seeds; GP192/SRS192 |20 итоговых+7 equivalence fits | late / fresh_theta_confirmation_20261007 |
| Fresh ranking confirmation |Другой новый 600-пул; 20 seeds; GP192/SRS192 |20 итоговых GP fits | late / fresh_task_ranking_confirmation_20261007 |
| Demo без готовых меток |600 текстов; 192 map+240 FE |19 code cells; 432 новых измерения | late / demo_20261007_cold |
| Повтор итогового demo |Тот же кеш; тот же научный конфиг |19 code cells; 0 новых измерений | late / demo_20261007_warm_final |

Остальные записи benchmark-реестра — технические контроли: random fraction; finite train sampling; независимый аудит сетки; проверка logits/JSD; стабильность загрузки; закрепление версий; сбор exact oracle; независимые refits/replay; live product; малый raw/log/large-target запуск; solver check; smoke запуска encoder/next/candidate notebooks; architecture check. Их параметры, результаты и фактические счётчики сохранены в benchmark_registry.json. Это не новые независимые научные датасеты.

**2. Численные результаты сравнений**

| Что сравнивали | Условия | Измеренный результат |
|---|---|---|
| Старый почти постоянный прогноз |Промежуточный per-domain math/toxic; RBF length_scale 0,1 |Расстояния nearest train≈0,90/1,19; корреляции≈1,8×10⁻¹⁸/1,1×10⁻³¹; возврат к train mean |
| Общий/отдельные GP |Ранняя Qwen/RBF/raw-серия; одни 96 random labels; два пула |MAE global0,007437/0,008547; per-domain0,007808/0,009098 |
| Остаточный GP |Ранний новый пул; 96 labels |MAE global0,009308; residual0,009644; subject mean0,009795 |
| RBF/Matérn3/2/Matérn5/2 |Октябрьский MMLU; 192 labels |Test MAE 0,008419/0,008379/0,008393 |
| GP/простые предикторы |Та же октябрьская сетка |MMLU: kNN0,008133 vsGP0,008379; Natural0: subject mean0,009044 vsGP0,009472 |
| Бюджет 96→384 |Два старых MiniLM/RBF-пула; те же контрольные splits |MAE 0,00807→0,00733 и 0,00989→0,00900; внутридоменный R²−0,091→0,098 и−0,197→−0,010 |
| Реальные/перемешанные JSD |Второй старый пул; shuffle только внутри предмета |При 96 MAE 0,00981/0,01045; при 288 0,00897/0,01001 |
| Локальность JSD в признаках |Nearest pairs vsrandom pairs внутри предметов |Средний квадрат JSD-разностей ближайших пар≈72% случайного контроля |
| Шесть статистик текста |Два старых пула; RBF; отдельно/с embeddings |Устойчивого выигрыша на обоих пулах нет; полные 120 строк в diagnostics |
| Дополнительные restart |Те же старые RBF-сценарии |Существенного изменения kernel/MAE/R² нет; 20 строк сохранены |
| κ 1/2/5/10 |Ранняя Qwen/RBF/raw/UCB-серия; 96 labels |Recall top10: пул 1 56/58/56/52%; пул 2 66/68/76/56% |
| GP+random / GP+σ |Октябрьский MMLU; start24→96; меняется policy при одном GP |Test MAE 0,009046/0,008116; θ-error12,07/9,75 п.п. |
| Random/UCB5 |Та же октябрьская сетка; поиск |Recall top10 MMLU18/58%; UCB Natural0/1/2: 34/40/50% |
| Random/UCB5: карта |Ранний новый MiniLM/RBF-пул; 96 labels |MAE 0,00931/0,01006; θ-error10,16/12,77 п.п. |
| Отбор возле порога |Ранний открытый пул |θ-error random10,16; balanced random9,83; threshold12,69; balanced threshold10,62 п.п. |
| Кластерный/случайный старт |Ранние два пула; MiniLM/RBF; 120→192; random tail |MAE пул 1 0,007650/0,007525; пул 2 0,008788/0,009019 |
| Кластерныйσ/случайный старт GP |Октябрьский product |Test θ-error8,68/8,80 п.п.; отдельное универсальное превосходство кластеров не установлено |
| Batch1/4/12 |Прежняя MiniLM/σ-схема |MAE≈0,008234/0,008234/0,008245; θ-error8,72/8,76/8,68 п.п.; 73 fits vs7; fit time≈11,3× |
| Qwen/MiniLM признаки |Ранняя RBF-серия; одни 96 labels; два пула |MAE MiniLM0,007912/0,009308; Qwen0,007395/0,008579; подход позже исключён требованием независимости |
| BGE CLS/MiniLM в старом product |Октябрьский старый пул; cluster+σ |Val θ-error11,81→9,06 п.п.; MAE 0,007364→0,007952; MAE ухудшается≈8% |
| BGE CLS/MiniLM в новом product |Новые 600; cluster+σ |Val MAE 0,008837→0,007788; test0,008576→0,008145; θval10,11→9,77 п.п. |
| Encoder/selection cross |Старый пул; фиксированные 192 IDs или features |BGE features val MAE хуже≈7,54%; BGE-selected IDs на MiniLM features хуже≈4,71%; эффекты не складываются |
| BGE/MiniLM на общих 192 IDs |Поздний development-контроль |Val MAE улучшения Ridge10,51%; Bayesian Ridge10,37%; KRR9,74%; GP9,26% |
| GP/KRR/Bayesian Ridge |Тот же BGE-контроль |Val MAE 0,007649/0,007732/0,008003 |
| Token-Ridge/pooled Ridge |4 октябрьских пула; budget192; среднее 5 seeds |MAE изменения MMLU−8,5%; Natural0−16,6%; Natural1−0,4%; Natural2−5,3% |
| Limited Token-GP/pooled GP |Те же 4 пула; budget192; среднее 5 seeds; TokenGP cap768 positions |MAE изменения MMLU+17,1%; Natural0+6,6%; Natural1+9,1%; Natural2+9,5% |
| PLS→GP/обычный GP |budget192; среднее 5 seeds; 2/4/8/16 components; train-only grouped CV |MAE изменения MMLU+0,6%; Natural0+6,4%; Natural1+3,5%; Natural2+4,5% |
| Top30/full JSD |Одни 120 текстов; ε 0,05 |θ75,83/55,0%; сдвиг 20,83 п.п.; Spearman 0,9922; top-10 overlap90% |
| Независимая JSD |8 реальных пар; FP32/CPU FP64 |Максимальное отличие≤4,54×10⁻⁷ |
| Raw/log JSD |40 парных случаев с budget96/192+product; приведённый val итог при budget192 |Val θ-error12,51→12,17 п.п.; product testθ8,20→9,45 п.п.; устойчивый выигрыш не установлен |
| Большие конечные y |1+s·exp(x), s1/10³/10⁶/10¹²; raw/log |Max≈2×10¹³; все конечны; R²raw≈0,934/log≈0,999; буквальная inf не подавалась |
| Encoder-prefix crop |40 fits; старые/исправленные features |MAE изменения 4 пулов−0,04%; −0,08%; +1,43%; +0,33% |
| GP/direct random fraction |Первая октябрьская сетка; 192 labels |θ-error GP/direct: MMLU10,64/8,13; Natural0 14,07/4,77; Natural1 13,86/3,63; Natural2 17,10/4,63 п.п. |
| GP/direct fraction/Bayesian Ridge |Поздний development; одни 192 random train IDs; MiniLM |Test θ-error5,335/7,521/5,261 п.п.; цель здесь — отдельный test, не полная train-популяция |
| MiniLMσ/MiniLMrandom/BGEσ/BGErandom |5 seeds; одинаковый старт 120 внутри пары; 192 labels |Val θ-error10,112/10,342/9,771/8,771 п.п.; MiniLMσ→BGErandom θ−13,26%, MAE−12,61%; два изменения одновременно |
| Postfreeze новый MMLU |Один seed100; 192 fit labels |Val/test MAE 0,008730/0,009431; R² 0,131/0,212; θ-error13,14/5,54 п.п.; Spearman 0,294/0,928 |
| Postfreeze natural |Один seed; FineWeb/FineMath; общий raw prefix |Test MAE 0,011865; R² 0,057; θ-error6,31 п.п.; правильный порядок только 2 источников |
| GP/direct ratio/SRS |Новый finite600-пул 6 окт; 20 seeds; 192 labels каждому |θ-error5,806/6,960/5,413 п.п.; ratio−GP1,154; CI[0,223; 2,218]; преимущество над SRS не установлено |
| HT/hybrid GP |Тот же finite pool |θ-errorHT11,025; hybrid5,810 п.п. |
| Точное ожидание SRS |Повторный расчёт открытого finite pool |Ожидаемая θ-error4,941 п.п.; не новый внешний тест |
| GP+random/GP+σ |Открытый finite pool; 20 paired seeds; 120→192 |θ-error5,805605/7,278262 п.п.; MAE 0,00994321/0,00961946; разностьθσ−random1,472658; CI[0,903495; 2,081204] |
| Fresh confirmation1: GP/SRS |Новый 600-пул; 20 seeds; 192 каждому |θ-error4,893/4,557 п.п.; SRS−GP−0,336; CI[−1,011; +0,398] |
| Fresh confirmation2: GP/SRS |Другой новый 600-пул; 20 seeds; 192 каждому |Domain Spearman 0,9714/0,9434; разность+0,0281; CI[+0,007; +0,0496]; 15/20wins |
| Fresh2: прогноз JSD |Общие невыбранные тексты; GP/SRS subject mean |MAE 0,008676/0,009634; снижение 9,94% |
| Fresh2: точнаяθ |Тот же pool/budget |θ-error3,993/4,096 п.п.; CI улучшения[−0,690; +0,939]; преимущество не подтверждено |
| Fresh2: измеренный top |Десятка полного предметного пула |Recall GP23,25%/SRS30,67% |
| Fresh2: прогноз следующих текстов |Десятка только среди оставшихся неизмеренных |Recall 25%; random expectation≈14,73%; эти 60 следующих измерений не выполнены в продукте |
| Fresh2: слабыйпредмет |moral_scenarios; внутридоменный прогноз |R²≈−0,503; Spearman≈0,061; forecast recall13%vsrandom≈14,79% |
| Fresh2: worst-domain ties |SRS ничьи в 16/20 планах |Истинный worst входит в минимальное множество SRS20/20; выбор одногоизничьих нельзя трактовать как крупный выигрыш GP |

Все CI по 20 seeds условны на соответствующий фиксированный 600-пул. Они не оценивают разброс по произвольным новым корпусам. Ранние top30/Qwen-feature результаты не сравниваются напрямую с поздними full-JSD/BGE.

**3. Конфигурация и фактический результат последнего notebook**

| Параметр | Значение |
|---|---|
| Notebook |qwen_gp_demo.ipynb |
| Teacher/student |Qwen3.5-2B-Base / Qwen3.5-0.8B-Base |
| Признаки |Независимый BGE-base-en-v1.5; последний слой; CLS; L2 |
| Модель |Один общий GP; Matérn-3/2 |
| Цель |Raw full-vocabulary JSD; натуральный логарифм внутри формулы JSD; ε=0,05 |
| Вход |Один общий raw prefix для обеих Qwen и BGE; лимиты 256 |
| Данные |6 MMLU-предметов ×100; 360 train /120 val /120 test |
| Начало |4 кластера ×5 представителей ×6 предметов =120 |
| Добор |72 random; batch 12; итог 192 fit labels |
| Проверка |240 отдельных val/test labels; в fit не поступают |
| Общая стоимость меток |432 измеренных документа; 168 неизмеренных |
| Validation |MAE 0,007789; R² 0,451; macro θ-error 9,79 п.п. |
| Test |MAE 0,008401; R² 0,531; macro θ-error 7,17 п.п. |
| Проход без готовых меток |432 новых измерения; 354,913745 с; exit0 |
| Повтор финального файла |0 новых измерений; 65,976606 с; exit0 |

На test внутридоменный R² отрицателен у biology, physics, medicine. На validation θ-error logical_fallacies≈28,55 п.п. Общий R² не отменяет эти результаты. Demo использует уже известный development-пул и проверяет выполнение продукта; не является новым подтверждением превосходства.

Общий raw prefix, идентичность кеша, полная область карты и отделённая FE исправлены функционально. Отдельное улучшение метрик от этих исправлений не установлено. Предыдущий FIXED: test MAE 0,008346 и θ-error 7,036 п.п.; последний demo: 0,008401 и 7,172 п.п. Это исправление корректности; рост точности не установлен.

**4. Полнота и источники**

- early_registry.json: 7 серий; 44 ссылки на первоисточники; полные извлечённые строки.
- diagnostics_registry.json: 9 диагностик; первичные результаты; аудиты учтены отдельно.
- benchmark_registry.json: 27 серий/контролей; 288 первичных файлов; все результаты каждого случая.
- late_registry.json: 12 серий/прогонов; 171 первичный источник; протоколы и агрегаты.
- all_experiments.json: объединённый реестр без удаления полей.
- ТЕХНИЧЕСКИЕ_ЗАПИСИ_GP_2026-10-07.md: конфигурации, агрегаты, счётчики и указатели источников для каждой записи.
- source_manifest.json: SHA256 файлов, пути в архиве, JSON pointers / ZIP members.

Значение null означает, что счётчик нельзя подтвердить первичным результатом. Например, точное число физических inference calls 6 октября не выводится из числа 600 уникальных cached labels: receipt одного блока не фиксирует первый расход. Неподтверждённые счётчики не подменены оценками.

Не выполнены: дообучение student; интеграция Markov/training; EI/PI/SUR/Thompson; передача буквальной inf; новый 20-seed GP-vs-SRS natural confirmation; полная проверка калибровки интервалов. Отдельная самостоятельная сетка entropy/NLL/logit целей не восстановлена по источникам и не объявляется выполненной.
